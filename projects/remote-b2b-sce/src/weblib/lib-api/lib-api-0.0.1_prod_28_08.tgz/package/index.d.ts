/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="lib-api" />
export * from './public-api';
//# sourceMappingURL=lib-api.d.ts.map