import * as i0 from '@angular/core';
import { Injectable, Component, NgModule } from '@angular/core';
import * as i1$1 from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';
import { formatDate } from '@angular/common';
import * as CryptoJS from 'crypto-js';
import { of, Observable } from 'rxjs';
import { catchError, mergeMap, map } from 'rxjs/operators';
import * as forge from 'node-forge';
import * as i1 from 'angular-device-information';

class LibApiService {
    constructor() { }
    static { this.ɵfac = function LibApiService_Factory(t) { return new (t || LibApiService)(); }; }
    static { this.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: LibApiService, factory: LibApiService.ɵfac, providedIn: 'root' }); }
}
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(LibApiService, [{
        type: Injectable,
        args: [{
                providedIn: 'root'
            }]
    }], function () { return []; }, null); })();

class LibApiComponent {
    constructor() { }
    ngOnInit() {
    }
    static { this.ɵfac = function LibApiComponent_Factory(t) { return new (t || LibApiComponent)(); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: LibApiComponent, selectors: [["la-lib-api"]], decls: 2, vars: 0, template: function LibApiComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "p");
            i0.ɵɵtext(1, " lib-api works! ");
            i0.ɵɵelementEnd();
        } }, encapsulation: 2 }); }
}
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(LibApiComponent, [{
        type: Component,
        args: [{ selector: 'la-lib-api', template: `
    <p>
      lib-api works!
    </p>
  ` }]
    }], function () { return []; }, null); })();

class LibApiModule {
    static { this.ɵfac = function LibApiModule_Factory(t) { return new (t || LibApiModule)(); }; }
    static { this.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: LibApiModule }); }
    static { this.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [HttpClientModule] }); }
}
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(LibApiModule, [{
        type: NgModule,
        args: [{
                declarations: [LibApiComponent],
                imports: [HttpClientModule
                ],
                exports: [LibApiComponent]
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(LibApiModule, { declarations: [LibApiComponent], imports: [HttpClientModule], exports: [LibApiComponent] }); })();

class CommonAppEnvService {
    constructor(deviceInformationService) {
        this.deviceInformationService = deviceInformationService;
        this.production = false;
        this.APP_ENVIRONMENT = "";
        this.aemUrl = "https://stage-aem-api.bajajfinserv.in/content/bajajfinserv/bajaj-super-app/in/en/offers/v1-1/loan-offers";
        this.maintanceAPIUrl = "https://dynamicbanners.bajajfinserv.in/bfldynamicbannerapi/get-fun-status?channel=SuperApp";
        this.API_URL = "https://superapp.bajajfinserv.in/apis/";
    }
    checkInternetStatus(source) {
        if (source != "WEB") {
            let internetConnectionPrompt = prompt('InternetConnectionCheck');
            if (internetConnectionPrompt == "true") {
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return true;
        }
    }
    //for opration api headers
    optHeaders(tokenForOptList, deviceId, sessionrefnumber, additonalInfo) {
        var OPTHeadersReq = {
            'Content-Type': "application/json",
            'Accept': "application/json",
            'Authorization': "dnh6MXQ5Y1NaOFYwUVB1OmxKQ19lNUNjQ214MkZBdEdyOGt2T2RMV1h2OQ==",
            'token': tokenForOptList,
            'Connection-from': "Upgrade-ws",
            'source': '3in1web',
            'deviceId': deviceId,
            "apiVersion": "v1",
            "operation": "operationallist",
            "sessionref": sessionrefnumber,
            "appVersion": "3in1_web_1.0.0.12",
            "additionalinfo1": additonalInfo
        };
        return OPTHeadersReq;
    }
    //for gateway api method call as per condition like connection from rest/upgarede ws
    conncetionFromApiHeaders(access_token, deviceId, conncetionFrom, sessionrefnumber, apiVersion) {
        var headers;
        if (conncetionFrom == 'rest') {
            headers = {
                'Content-Type': "application/json",
                'Accept': "application/json",
                'Authorization': "dnh6MXQ5Y1NaOFYwUVB1OmxKQ19lNUNjQ214MkZBdEdyOGt2T2RMV1h2OQ==",
                'token': access_token,
                'Connection-from': "rest",
                'source': '3in1web',
                'deviceId': deviceId,
                'apiVersion': apiVersion,
                'sessionref': sessionrefnumber
            };
        }
        else {
            headers = {
                'Content-Type': "application/json",
                'Accept': "application/json",
                'Authorization': "dnh6MXQ5Y1NaOFYwUVB1OmxKQ19lNUNjQ214MkZBdEdyOGt2T2RMV1h2OQ==",
                'token': access_token,
                'Connection-from': "Upgrade-ws",
                'source': '3in1web',
                'deviceId': deviceId,
                "apiVersion": apiVersion,
                'sessionref': sessionrefnumber
            };
        }
        return headers;
    }
    conncetionFromApiHeadersREST(access_token, deviceId, conncetionFrom, sessionrefnumber, apiVersion) {
        var headers;
        if (conncetionFrom == 'rest') {
            headers = {
                'Content-Type': "application/json",
                'Accept': "application/json",
                'Authorization': "dnh6MXQ5Y1NaOFYwUVB1OmxKQ19lNUNjQ214MkZBdEdyOGt2T2RMV1h2OQ==",
                'token': access_token,
                'Connection-from': "rest",
                'source': '3in1web',
                'deviceId': deviceId,
                'apiVersion': apiVersion,
                'sessionref': sessionrefnumber,
                "appVersion": "4.0.30"
            };
        }
        else {
            headers = {
                'Content-Type': "application/json",
                'Accept': "application/json",
                'Authorization': "dnh6MXQ5Y1NaOFYwUVB1OmxKQ19lNUNjQ214MkZBdEdyOGt2T2RMV1h2OQ==",
                'token': access_token,
                'Connection-from': "Upgrade-ws",
                'source': '3in1web',
                'deviceId': deviceId,
                "apiVersion": apiVersion,
                'sessionref': sessionrefnumber,
                "appVersion": "4.0.30"
            };
        }
        return headers;
    }
    //for emiPodApi Headers
    emiPodApiHeaders(access_token, deviceId) {
        let headers = {
            'Content-Type': "application/json",
            'Accept': "application/json",
            'Authorization': "dnh6MXQ5Y1NaOFYwUVB1OmxKQ19lNUNjQ214MkZBdEdyOGt2T2RMV1h2OQ==",
            'token': access_token,
            'Connection-from': "rest",
            'source': 'emipod',
            'deviceId': deviceId,
            "apiVersion": "v1"
        };
        return headers;
    }
    //for OuthOtpApi
    OuthOtpApiHeaders(deviceId, sessionrefnumber, apiVersion) {
        let headers = {
            // 'Content-Type': "application/json",
            // 'Accept': "json",
            // 'Authorization': "X0Z5Rm0xLTNjemNqWjlNOnhfTS1ROXlyMDdCYXhOSUZBUFRQSm5CMUE3TQ==",
            // 'Connection-from': "rest",
            // 'source': "3in1",
            // 'apiVersion': "v2",
            // 'deviceId': deviceId,
            // 'sessionref' : sessionrefnumber
            'Content-Type': "application/json",
            'Accept': "application/json",
            'Authorization': "dnh6MXQ5Y1NaOFYwUVB1OmxKQ19lNUNjQ214MkZBdEdyOGt2T2RMV1h2OQ==",
            'Connection-from': "rest",
            'source': '3in1web',
            'deviceId': deviceId,
            "apiVersion": apiVersion,
            "sessionref": sessionrefnumber
        };
        return headers;
    }
    //for OuthOtpValidate
    OuthOtpValidateApiHeaders(sessionrefnumber, apiVersion) {
        let headers = {
            'Content-Type': "application/json",
            'Accept': "application/json",
            'Authorization': "aFZ4aFJuWUpLV1JKM1o1Ol9yODNnVVlWWHluOUZ6VGpUd0JrQUJYa3ZBcDk=",
            'token': '',
            'Connection-from': "rest",
            'source': "3in1web",
            'apiVersion': apiVersion,
            'sessionref': sessionrefnumber
        };
        return headers;
    }
    //for OuthtokenApi
    OuthtokenApiHeaders(accessToken, deviceId, sessionrefnumber, apiVersion) {
        let headers = {
            'Content-Type': "application/json",
            'Accept': "application/json",
            'Authorization': 'dnh6MXQ5Y1NaOFYwUVB1OmxKQ19lNUNjQ214MkZBdEdyOGt2T2RMV1h2OQ==',
            'token': accessToken,
            'Connection-from': "rest",
            'source': '3in1web',
            'apiVersion': apiVersion,
            'deviceId': deviceId,
            'sessionref': sessionrefnumber
        };
        return headers;
    }
    //for common api call header 
    CommonApiHeaders(access_token, deviceId, sessionrefnumber, apiVersion) {
        let headers = {
            'Content-Type': "application/json",
            'Accept': "application/json",
            'Authorization': "dnh6MXQ5Y1NaOFYwUVB1OmxKQ19lNUNjQ214MkZBdEdyOGt2T2RMV1h2OQ==",
            'token': access_token,
            'Connection-from': "Upgrade-ws",
            'source': '3in1web',
            'deviceId': deviceId,
            "apiVersion": apiVersion,
            'sessionref': sessionrefnumber
        };
        return headers;
    }
    refreshTokenApiHeaders(access_token, deviceId, sessionrefnumber) {
        let headers = {
            'Content-Type': "application/json",
            'Accept': "application/json",
            'Authorization': "dnh6MXQ5Y1NaOFYwUVB1OmxKQ19lNUNjQ214MkZBdEdyOGt2T2RMV1h2OQ==",
            'token': access_token,
            'Connection-from': "Upgrade-ws",
            'source': '3in1web',
            'sessionref': sessionrefnumber
        };
        return headers;
    }
    //console log function
    consoleLog(data) {
        if (!this.production) {
            console.log(data);
        }
    }
    handleError(error) {
        let return_JSON;
        if (error.error instanceof ErrorEvent) {
            // Client-side errors
            return_JSON = {
                "STATUS": "E",
                "API_RESPONSE": "",
                "MESSAGE": `Error: ${error.error.message}`,
                "STATUS_CODE": "ERROR"
            };
        }
        else {
            // Server-side errors
            return_JSON = {
                "STATUS": "E",
                "API_RESPONSE": "",
                "MESSAGE": `Error: ${error.message}`,
                "STATUS_CODE": `${error.status}`,
            };
        }
        return of(return_JSON);
    }
    //to get device info : device id and other info
    getDeviceInfo() {
        if (this.deviceInformationService.isMobile()) {
            this.deviceId = this.deviceInformationService.getDeviceInfo().browser;
        }
        else if (this.deviceInformationService.isTablet()) {
            this.deviceId = this.deviceInformationService.getDeviceInfo().browser;
        }
        else {
            this.deviceId = this.deviceInformationService.getDeviceInfo().browser;
        }
        return this.deviceId;
    }
    static { this.ɵfac = function CommonAppEnvService_Factory(t) { return new (t || CommonAppEnvService)(i0.ɵɵinject(i1.AngularDeviceInformationService)); }; }
    static { this.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: CommonAppEnvService, factory: CommonAppEnvService.ɵfac, providedIn: 'root' }); }
}
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CommonAppEnvService, [{
        type: Injectable,
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: i1.AngularDeviceInformationService }]; }, null); })();

class ConnectionMgrService {
    constructor(httpClient, environment) {
        this.httpClient = httpClient;
        this.environment = environment;
        this.mobileNumber = "";
        this.storageKeyCipher = "abcdefStorageOpt";
        this.tokenkey = 'abcdefTokenKeyOp';
        this.globalSource = "";
        var today = new Date();
        var conversionChar = formatDate(today, 'yyyy-MM-dd hh:mm:ss a', 'en-US', '+0530');
        conversionChar = conversionChar.replace(" ", "");
        conversionChar = conversionChar.replace(":", "");
        conversionChar = conversionChar.replace("-", "");
        conversionChar = conversionChar.replace("-", "");
        conversionChar = conversionChar.replace(":", "");
        conversionChar = conversionChar.replace(" ", "");
        for (var i = 0; i < 20; i++) {
            conversionChar += conversionChar.charAt(Math.floor(Math.random() * 32));
        }
        this.tokenForOptList = conversionChar;
    }
    //for init method and call operation list and save opt list
    initLib(source) {
        console.log("Prod Build 18-03-2024");
        var randomNumberFordeviceId = this.generateRandom();
        if (this.environment.getDeviceInfo() != "" || this.environment.getDeviceInfo() != undefined) {
            this.device_id = randomNumberFordeviceId + this.environment.getDeviceInfo();
        }
        else {
            this.device_id = randomNumberFordeviceId + 'web';
        }
        this.sessionrefnumber = this.generateRandom().toString();
        this.globalSource = source;
        var operationId = 'operationallist';
        var method = "POST";
        var OriginalOPTKey = "W1r4srgzHo4z";
        var encryptKey = this.tokenForOptList.substring(0, 4) + OriginalOPTKey;
        var requestBody = {
            "appversion": "3in1web_web_1.0.0.12",
            "channel": "3in1web",
            "deviceId": this.device_id,
            "token": this.tokenForOptList
        };
        let publicKeyPEM = "-----BEGIN PUBLIC KEY-----MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDltEGNmQ56wA1UmF9Svp5Iak+V5ys1MaZf8+IUdEvyFyTvak4SLJfG9LbntLDjTuLq9cWrInMIVOLkEg3JNVf3la70bl6sqF9dC/T4Rs2CaUsTpE9aRVJ13odhZWBO1tjxG5peyH0Xw2LTthoR88aGHBTicsDFmAhRJ95tIDqJlQIDAQAB-----END PUBLIC KEY-----";
        let additonalInfoHeaderDecrypted = "dnh6MXQ5Y1NaOFYwUVB1OmxKQ19lNUNjQ214MkZBdEdyOGt2T2RMV1h2OQ==" + '_' + '3in1web' + '_' + this.device_id;
        let additonalInfo = this.encryptRSA(additonalInfoHeaderDecrypted, publicKeyPEM);
        if (this.environment.checkInternetStatus(source)) {
            if (source == "WEB") {
                try {
                    let URL = this.environment.API_URL + operationId;
                    var reqParams;
                    if (encryptKey != "") {
                        reqParams = this.encryptionFun(requestBody, encryptKey, "");
                    }
                    else {
                        reqParams = requestBody;
                    }
                    var response;
                    var apiResponse;
                    var api_Response;
                    var headers = {};
                    headers = this.environment.optHeaders(this.tokenForOptList, this.device_id, this.sessionrefnumber, additonalInfo);
                    return Observable.create((observer) => {
                        let localData = this.httpClient.post(URL, reqParams, { headers }).pipe(catchError(this.environment.handleError));
                        localData.subscribe(res => {
                            this.result = res;
                            response = this.result;
                            if (encryptKey != "") {
                                response = response.toString();
                                response = response.replaceAll('"', '');
                                // this.environment.consoleLog('ENCRYPTED response FROM HTTP: ' + response);
                                apiResponse = JSON.parse(this.decryptionFun(response, encryptKey, ""));
                            }
                            else {
                                apiResponse = JSON.parse(this.result);
                            }
                            //console.log('apiResponse', apiResponse);
                            if (this.operationData == null) {
                                let Str = 'operationListData';
                                var ciphertext = this.encryptionFun(apiResponse, this.storageKeyCipher, "");
                                localStorage.setItem('operationListData', ciphertext);
                                this.operationListData = ciphertext;
                            }
                            let fail_response = {
                                "STATUS": "E",
                                "API_RESPONSE": "",
                                "MESSAGE": "Sorry unable to connect please try again",
                                "STATUS_CODE": "ERROR"
                            };
                            api_Response = apiResponse ? apiResponse : fail_response;
                            this.return_JSON = {
                                "STATUS": "S",
                                "MESSAGE": "SUCCESS",
                                "STATUS_CODE": "SUCCESS",
                                "API_RESPONSE": api_Response
                            };
                            //console.log('this.return_JSON', this.return_JSON);
                            observer.next(this.return_JSON);
                            observer.complete();
                        }, (err) => {
                            observer.next(err);
                            observer.complete();
                        });
                    });
                }
                catch (ex) {
                    this.return_JSON = {
                        "STATUS": "E",
                        "API_RESPONSE": "",
                        "MESSAGE": "EXCEPTION : " + ex.message,
                        "STATUS_CODE": "EXCEPTION",
                    };
                }
            }
            else {
                this.return_JSON = {
                    "STATUS": "E",
                    "STATUS_CODE": "ERROR",
                    "API_RESPONSE": "",
                    "MESSAGE": "Platfrom is app"
                };
                return of(JSON.stringify(this.return_JSON));
            }
        }
        else {
            this.return_JSON = {
                "STATUS": "E",
                "STATUS_CODE": "ERROR",
                "API_RESPONSE": "",
                "MESSAGE": "Please check your Internet Connection."
            };
        }
        // this.environment.consoleLog('FINAL JSON RESPONSE FOR PAGE: ' + JSON.stringify(this.return_JSON));
        return this.return_JSON;
    }
    encryptRSA(nonEncText, publicKeyPEM) {
        const rsa = forge.pki.publicKeyFromPem(publicKeyPEM);
        return btoa(rsa.encrypt(nonEncText));
    }
    initLibREST(source) {
        console.log("Prod Build 18-03-2024");
        var randomNumberFordeviceId = this.generateRandom();
        this.device_id = randomNumberFordeviceId + 'APP';
        this.sessionrefnumber = this.generateRandom().toString() ? this.generateRandom().toString() : "gyjdyustdysud";
        this.globalSource = source;
        var operationId = 'operationallist';
        var method = "POST";
        var OriginalOPTKey = "W1r4srgzHo4z";
        var encryptKey = this.tokenForOptList.substring(0, 4) + OriginalOPTKey;
        var requestBody = {
            "appversion": "3in1web_web_1.0.0.12",
            "channel": "3in1web",
            "deviceId": this.device_id,
            "token": this.tokenForOptList
        };
        let publicKeyPEM = "-----BEGIN PUBLIC KEY-----MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDltEGNmQ56wA1UmF9Svp5Iak+V5ys1MaZf8+IUdEvyFyTvak4SLJfG9LbntLDjTuLq9cWrInMIVOLkEg3JNVf3la70bl6sqF9dC/T4Rs2CaUsTpE9aRVJ13odhZWBO1tjxG5peyH0Xw2LTthoR88aGHBTicsDFmAhRJ95tIDqJlQIDAQAB-----END PUBLIC KEY-----";
        let additonalInfoHeaderDecrypted = "dnh6MXQ5Y1NaOFYwUVB1OmxKQ19lNUNjQ214MkZBdEdyOGt2T2RMV1h2OQ==" + '_' + '3in1web' + '_' + this.device_id;
        let additonalInfo = this.encryptRSA(additonalInfoHeaderDecrypted, publicKeyPEM);
        if (this.environment.checkInternetStatus(source)) {
            try {
                let URL = this.environment.API_URL + operationId;
                var reqParams;
                if (encryptKey != "") {
                    reqParams = this.encryptionFun(requestBody, encryptKey, "");
                }
                else {
                    reqParams = requestBody;
                }
                var response;
                var apiResponse;
                var api_Response;
                var headers = {};
                headers = this.environment.optHeaders(this.tokenForOptList, this.device_id, this.sessionrefnumber, additonalInfo);
                return Observable.create((observer) => {
                    let localData = this.httpClient.post(URL, reqParams, { headers }).pipe(catchError(this.environment.handleError));
                    localData.subscribe(res => {
                        this.result = res;
                        response = this.result;
                        if (encryptKey != "") {
                            response = response.toString();
                            response = response.replaceAll('"', '');
                            apiResponse = JSON.parse(this.decryptionFun(response, encryptKey, ""));
                        }
                        else {
                            apiResponse = JSON.parse(this.result);
                        }
                        if (this.operationData == null) {
                            let Str = 'operationListData';
                            var ciphertext = this.encryptionFun(apiResponse, this.storageKeyCipher, "");
                            localStorage.setItem('operationListData', ciphertext);
                            this.operationListData = ciphertext;
                        }
                        let fail_response = {
                            "STATUS": "E",
                            "API_RESPONSE": "",
                            "MESSAGE": "Sorry unable to connect please try again",
                            "STATUS_CODE": "ERROR",
                        };
                        api_Response = apiResponse ? apiResponse : fail_response;
                        this.return_JSON = {
                            "STATUS": "S",
                            "MESSAGE": "SUCCESS",
                            "STATUS_CODE": "SUCCESS",
                            "API_RESPONSE": api_Response
                        };
                        observer.next(this.return_JSON);
                        observer.complete();
                    }, (err) => {
                        observer.next(err);
                        observer.complete();
                    });
                });
            }
            catch (ex) {
                this.return_JSON = {
                    "STATUS": "E",
                    "API_RESPONSE": api_Response,
                    "MESSAGE": "EXCEPTION : " + ex.message,
                    "STATUS_CODE": "EXCEPTION",
                };
            }
        }
        else {
            this.return_JSON = {
                "STATUS": "E",
                "STATUS_CODE": "ERROR",
                "API_RESPONSE": "",
                "MESSAGE": "Please check your Internet Connection."
            };
        }
        return of(this.return_JSON);
    }
    // generate random 8 digit number
    generateRandom() {
        let number = Math.floor(Math.random() * 100000000);
        //console.log(number)
        return number;
    }
    //for api calling : all user api calling
    gateWayApiCalling(operationId, requestBody, conncetionFrom, additonalHeaders, source) {
        //commented 
        // this.device_id = this.environment.getDeviceInfo();
        // if ((this.device_id == "" && this.device_id == undefined)) {
        //   this.device_id = operationId + source;
        // }
        //console.log('this.device_id', this.device_id);
        this.globalSource = source;
        if (this.globalSource == "WEB" || this.globalSource == "web" || this.globalSource == "Web") {
            if (this.environment.checkInternetStatus(source)) {
                this.access_token = localStorage.getItem("access_token");
                //console.log("AccessToken", this.access_token)
                if (this.access_token != null && this.access_token != "") {
                    try {
                        let URL = this.environment.API_URL + operationId;
                        var reqParams;
                        this.operationData = this.ConvertOptList();
                        var encryptKey;
                        var apiVersion = "v1";
                        if (this.operationData != null) {
                            this.operationData.find((item) => {
                                if (item.publicurl == operationId) {
                                    encryptKey = item.hashcode;
                                    apiVersion = item.apiversion == undefined ? "v1" : item.apiversion;
                                    //console.log("EncKey", encryptKey);
                                }
                            });
                        }
                        else {
                            this.initLib(this.globalSource).subscribe((res) => {
                                var api = res;
                                if (res == null) {
                                    let Str = 'operationListData';
                                    var ciphertext = this.encryptionFun(res, this.storageKeyCipher, "");
                                    localStorage.setItem('operationListData', ciphertext);
                                    this.operationListData = ciphertext;
                                    this.operationData = this.ConvertOptList();
                                    if (this.operationData != null) {
                                        this.operationData.find((item) => {
                                            if (item.publicurl == operationId) {
                                                encryptKey = item.hashcode;
                                                apiVersion = item.apiversion == undefined ? "v1" : item.apiversion;
                                            }
                                        });
                                    }
                                }
                            });
                        }
                        if (encryptKey != '' && encryptKey != null) {
                            reqParams = this.encryptionFun(requestBody, encryptKey, "");
                        }
                        else {
                            reqParams = requestBody;
                        }
                        var response;
                        var apiResponse;
                        var api_Response;
                        var headers = {};
                        //headers function call in app env service
                        headers = this.environment.conncetionFromApiHeaders(this.access_token, this.device_id, conncetionFrom, this.sessionrefnumber, apiVersion);
                        if (additonalHeaders != null && additonalHeaders != "") {
                            for (const key in additonalHeaders) {
                                headers[key] = additonalHeaders[key];
                            }
                            // headers.appendedData = additonalHeaders
                            // headers.additonalHeaders = additonalHeaders;
                        }
                        //console.log('headers', headers, encryptKey);
                        return Observable.create((observer) => {
                            let localData = this.httpClient.post(URL, reqParams, { headers }).pipe(catchError(this.environment.handleError));
                            localData.subscribe(res => {
                                this.result = res;
                                response = this.result;
                                if (encryptKey != "") {
                                    if (res.STATUS == 'E') {
                                        apiResponse = this.result;
                                    }
                                    else {
                                        response = response.toString();
                                        response = response.replaceAll('"', '');
                                        apiResponse = JSON.parse(this.decryptionFun(response, encryptKey, ""));
                                    }
                                }
                                else {
                                    apiResponse = this.result;
                                }
                                let fail_response = {
                                    "STATUS": "E",
                                    "API_RESPONSE": "",
                                    "MESSAGE": "Sorry unable to connect please try again",
                                    "STATUS_CODE": "408"
                                };
                                api_Response = apiResponse ? apiResponse : fail_response;
                                this.return_JSON = {
                                    "STATUS": "S",
                                    "MESSAGE": "SUCCESS",
                                    "STATUS_CODE": "SUCCESS",
                                    "API_RESPONSE": api_Response
                                };
                                observer.next(this.return_JSON);
                                // observer.complete();
                            }, (err) => {
                                // IF Status code 500 or 4014 call refresh api after that call gateway api  
                                this.return_JSON = {
                                    "STATUS": "S",
                                    "MESSAGE": "Failure",
                                    "STATUS_CODE": err.STATUS_CODE,
                                    "API_RESPONSE": api_Response
                                };
                            });
                        });
                    }
                    catch (ex) {
                        this.return_JSON = {
                            "STATUS": "E",
                            "API_RESPONSE": "",
                            "MESSAGE": "EXCEPTION : " + ex.message,
                            "STATUS_CODE": "505"
                        };
                    }
                }
                else {
                    this.return_JSON = {
                        "STATUS": "E",
                        "STATUS_CODE": "500",
                        "API_RESPONSE": "",
                        "MESSAGE": "Access Token blank"
                    };
                }
            }
            else {
                this.return_JSON = {
                    "STATUS": "E",
                    "STATUS_CODE": "ERROR",
                    "API_RESPONSE": "",
                    "MESSAGE": "Please check your Internet Connection."
                };
            }
        }
        else {
            let apiRequestData = {
                "encryptionKey": "",
                "payload": requestBody,
                "operation": operationId
            };
            let headerData = {
                "sessionref": this.device_id
            };
            if (additonalHeaders != null && additonalHeaders != "") {
                for (const key in additonalHeaders) {
                    headerData[key] = additonalHeaders[key];
                }
            }
            apiRequestData.headers = headerData;
            var fail_response = {
                "STATUS": "E",
                "STATUS_CODE": "7010",
                "API_RESPONSE": "",
                "MESSAGE": "Didn't get response form app"
            };
            this.promptres = prompt("callAPI://" + JSON.stringify(apiRequestData));
            this.return_JSON = this.promptres ? this.promptres : fail_response;
            return of(this.return_JSON);
        }
        return of(this.return_JSON);
    }
    gateWayApiCallingV2(operationId, requestBody, conncetionFrom, additonalHeaders, source, accessToken) {
        this.globalSource = source;
        if (this.globalSource == "WEB" || this.globalSource == "web" || this.globalSource == "Web") {
            if (this.environment.checkInternetStatus(source)) {
                this.access_token = localStorage.getItem("access_token");
                //console.log("AccessToken", this.access_token)
                if (this.access_token != null && this.access_token != "") {
                    try {
                        let URL = this.environment.API_URL + operationId;
                        var reqParams;
                        this.operationData = this.ConvertOptList();
                        var encryptKey;
                        var apiVersion = "v1";
                        if (this.operationData != null) {
                            this.operationData.find((item) => {
                                if (item.publicurl == operationId) {
                                    encryptKey = item.hashcode;
                                    apiVersion = item.apiversion == undefined ? "v1" : item.apiversion;
                                    //console.log("EncKey", encryptKey);
                                }
                            });
                        }
                        else {
                            this.initLib(this.globalSource).subscribe((res) => {
                                var api = res;
                                if (res == null) {
                                    let Str = 'operationListData';
                                    var ciphertext = this.encryptionFun(res, this.storageKeyCipher, "");
                                    localStorage.setItem('operationListData', ciphertext);
                                    this.operationListData = ciphertext;
                                    this.operationData = this.ConvertOptList();
                                    if (this.operationData != null) {
                                        this.operationData.find((item) => {
                                            if (item.publicurl == operationId) {
                                                encryptKey = item.hashcode;
                                                apiVersion = item.apiversion == undefined ? "v1" : item.apiversion;
                                            }
                                        });
                                    }
                                }
                            });
                        }
                        if (encryptKey != '' && encryptKey != null) {
                            reqParams = this.encryptionFun(requestBody, encryptKey, "");
                        }
                        else {
                            reqParams = requestBody;
                        }
                        var response;
                        var apiResponse;
                        var api_Response;
                        var headers = {};
                        //headers function call in app env service
                        headers = this.environment.conncetionFromApiHeaders(this.access_token, this.device_id, conncetionFrom, this.sessionrefnumber, apiVersion);
                        if (additonalHeaders != null && additonalHeaders != "") {
                            // headers.additonalHeaders = additonalHeaders;
                        }
                        //console.log('headers', headers, encryptKey);
                        return Observable.create((observer) => {
                            let localData = this.httpClient.post(URL, reqParams, { headers }).pipe(catchError(this.environment.handleError));
                            localData.subscribe(res => {
                                this.result = res;
                                response = this.result;
                                if (encryptKey != "") {
                                    if (res.STATUS == 'E') {
                                        apiResponse = this.result;
                                    }
                                    else {
                                        response = response.toString();
                                        response = response.replaceAll('"', '');
                                        apiResponse = JSON.parse(this.decryptionFun(response, encryptKey, ""));
                                    }
                                }
                                else {
                                    apiResponse = this.result;
                                }
                                let fail_response = {
                                    "STATUS": "E",
                                    "API_RESPONSE": "",
                                    "MESSAGE": "Sorry unable to connect please try again",
                                    "STATUS_CODE": "408"
                                };
                                api_Response = apiResponse ? apiResponse : fail_response;
                                this.return_JSON = {
                                    "STATUS": "S",
                                    "MESSAGE": "SUCCESS",
                                    "STATUS_CODE": "SUCCESS",
                                    "API_RESPONSE": api_Response
                                };
                                observer.next(this.return_JSON);
                                // observer.complete();
                            }, (err) => {
                                // IF Status code 500 or 4014 call refresh api after that call gateway api  
                                this.return_JSON = {
                                    "STATUS": "S",
                                    "MESSAGE": "Failure",
                                    "STATUS_CODE": err.STATUS_CODE,
                                    "API_RESPONSE": api_Response
                                };
                            });
                        });
                    }
                    catch (ex) {
                        this.return_JSON = {
                            "STATUS": "E",
                            "API_RESPONSE": "",
                            "MESSAGE": "EXCEPTION : " + ex.message,
                            "STATUS_CODE": "505"
                        };
                    }
                }
                else {
                    this.return_JSON = {
                        "STATUS": "E",
                        "STATUS_CODE": "500",
                        "API_RESPONSE": "",
                        "MESSAGE": "Access Token blank"
                    };
                }
            }
            else {
                this.return_JSON = {
                    "STATUS": "E",
                    "STATUS_CODE": "ERROR",
                    "API_RESPONSE": "",
                    "MESSAGE": "Please check your Internet Connection."
                };
            }
            return of(this.return_JSON);
        }
        else {
            let apiRequestData = {
                "encryptionKey": "",
                "payload": requestBody,
                "operation": operationId
            };
            let headerData = {
                "sessionref": this.device_id
            };
            apiRequestData.headers = headerData;
            if (additonalHeaders != null || additonalHeaders != "") {
                // apiRequestData.headers = additonalHeaders;
            }
            var fail_response = {
                "STATUS": "E",
                "STATUS_CODE": "7010",
                "statusCode": "7010",
                "API_RESPONSE": "",
                "MESSAGE": "Didn't get response form app"
            };
            this.promptres = prompt("callAPI://" + JSON.stringify(apiRequestData));
            this.return_JSON = this.promptres ? this.promptres : fail_response;
            try {
                this.promptres = JSON.parse(this.promptres);
                if ((this.promptres.hasOwnProperty('STATUS_CODE') && this.promptres['STATUS_CODE'] == '7010') ||
                    (this.promptres.hasOwnProperty('statusCode') && this.promptres['statusCode'] == '7010') ||
                    (this.promptres.hasOwnProperty('status_code') && this.promptres['status_code'] == '7010')) {
                    this.return_JSON = Observable.create((observer) => {
                        this.initLibREST("APP").subscribe((res) => {
                            console.log("Init lib Rest", res);
                            if (res.API_RESPONSE.hasOwnProperty('operationList') && res.API_RESPONSE.operationList.length > 0) {
                                this.gateWayApiCallingREST(operationId, requestBody, conncetionFrom, additonalHeaders, source, accessToken).
                                    subscribe((response) => {
                                    this.return_JSON = response.API_RESPONSE;
                                    observer.next(JSON.stringify(this.return_JSON));
                                });
                            }
                        });
                    });
                    return of(this.return_JSON);
                }
            }
            catch {
                return of(this.return_JSON);
            }
            return of(this.return_JSON);
        }
    }
    gateWayApiCallingV3(operationId, requestBody, conncetionFrom, additonalHeaders, source, accessToken) {
        this.globalSource = source;
        if (this.globalSource == "WEB" || this.globalSource == "web" || this.globalSource == "Web") {
            if (this.environment.checkInternetStatus(source)) {
                this.access_token = localStorage.getItem("access_token");
                //console.log("AccessToken", this.access_token)
                if (this.access_token != null && this.access_token != "") {
                    try {
                        let URL = this.environment.API_URL + operationId;
                        var reqParams;
                        this.operationData = this.ConvertOptList();
                        var encryptKey;
                        var apiVersion = "v1";
                        if (this.operationData != null) {
                            this.operationData.find((item) => {
                                if (item.publicurl == operationId) {
                                    encryptKey = item.hashcode;
                                    apiVersion = item.apiversion == undefined ? "v1" : item.apiversion;
                                    //console.log("EncKey", encryptKey);
                                }
                            });
                        }
                        else {
                            this.initLib(this.globalSource).subscribe((res) => {
                                var api = res;
                                if (res == null) {
                                    let Str = 'operationListData';
                                    var ciphertext = this.encryptionFun(res, this.storageKeyCipher, "");
                                    localStorage.setItem('operationListData', ciphertext);
                                    this.operationListData = ciphertext;
                                    this.operationData = this.ConvertOptList();
                                    if (this.operationData != null) {
                                        this.operationData.find((item) => {
                                            if (item.publicurl == operationId) {
                                                encryptKey = item.hashcode;
                                                apiVersion = item.apiversion == undefined ? "v1" : item.apiversion;
                                            }
                                        });
                                    }
                                }
                            });
                        }
                        if (encryptKey != '' && encryptKey != null) {
                            reqParams = this.encryptionFun(requestBody, encryptKey, "");
                        }
                        else {
                            reqParams = requestBody;
                        }
                        var response;
                        var apiResponse;
                        var api_Response;
                        var headers = {};
                        //headers function call in app env service
                        headers = this.environment.conncetionFromApiHeaders(this.access_token, this.device_id, conncetionFrom, this.sessionrefnumber, apiVersion);
                        if (additonalHeaders != null && additonalHeaders != "") {
                            for (const key in additonalHeaders) {
                                headers[key] = additonalHeaders[key];
                            }
                        }
                        return Observable.create((observer) => {
                            let localData = this.httpClient.post(URL, reqParams, { headers }).pipe(catchError(this.environment.handleError));
                            localData.subscribe(res => {
                                this.result = res;
                                response = this.result;
                                if (encryptKey != "") {
                                    if (res.STATUS == 'E') {
                                        apiResponse = this.result;
                                    }
                                    else {
                                        response = response.toString();
                                        response = response.replaceAll('"', '');
                                        apiResponse = JSON.parse(this.decryptionFun(response, encryptKey, ""));
                                    }
                                }
                                else {
                                    apiResponse = this.result;
                                }
                                let fail_response = {
                                    "STATUS": "E",
                                    "API_RESPONSE": "",
                                    "MESSAGE": "Sorry unable to connect please try again",
                                    "STATUS_CODE": "408"
                                };
                                api_Response = apiResponse ? apiResponse : fail_response;
                                this.return_JSON = {
                                    "STATUS": "S",
                                    "MESSAGE": "SUCCESS",
                                    "STATUS_CODE": "SUCCESS",
                                    "API_RESPONSE": api_Response
                                };
                                observer.next(this.return_JSON);
                                // observer.complete();
                            }, (err) => {
                                // IF Status code 500 or 4014 call refresh api after that call gateway api  
                                this.return_JSON = {
                                    "STATUS": "S",
                                    "MESSAGE": "Failure",
                                    "STATUS_CODE": err.STATUS_CODE,
                                    "API_RESPONSE": api_Response
                                };
                            });
                        });
                    }
                    catch (ex) {
                        this.return_JSON = {
                            "STATUS": "E",
                            "API_RESPONSE": "",
                            "MESSAGE": "EXCEPTION : " + ex.message,
                            "STATUS_CODE": "505"
                        };
                    }
                }
                else {
                    this.return_JSON = {
                        "STATUS": "E",
                        "STATUS_CODE": "500",
                        "API_RESPONSE": "",
                        "MESSAGE": "Access Token blank"
                    };
                }
            }
            else {
                this.return_JSON = {
                    "STATUS": "E",
                    "STATUS_CODE": "ERROR",
                    "API_RESPONSE": "",
                    "MESSAGE": "Please check your Internet Connection."
                };
            }
            return of(this.return_JSON);
        }
        else {
            let apiRequestData = {
                "encryptionKey": "",
                "payload": requestBody,
                "operation": operationId
            };
            let headerData = {
                "sessionref": this.device_id
            };
            if (additonalHeaders != null && additonalHeaders != "") {
                for (const key in additonalHeaders) {
                    headerData[key] = additonalHeaders[key];
                }
            }
            apiRequestData.headers = headerData;
            var fail_response = {
                "STATUS": "E",
                "STATUS_CODE": "7010",
                "statusCode": "7010",
                "API_RESPONSE": "",
                "MESSAGE": "Didn't get response form app"
            };
            var promptRes = prompt("callAPI://" + JSON.stringify(apiRequestData));
            // debug 
            // var promptRes = JSON.stringify(fail_response);
            var retJson = promptRes ? promptRes : fail_response;
            try {
                //debug
                // var is_app_api_not_found = true
                var is_app_api_not_found = promptRes === "Api Name: " + operationId + " not found" ? true : false;
                if (!is_app_api_not_found) {
                    promptRes = JSON.parse(promptRes);
                }
                if ((promptRes.hasOwnProperty('STATUS_CODE') && promptRes['STATUS_CODE'] == '7010') ||
                    (promptRes.hasOwnProperty('statusCode') && promptRes['statusCode'] == '7010') ||
                    (promptRes.hasOwnProperty('status_code') && promptRes['status_code'] == '7010') ||
                    (promptRes.hasOwnProperty('statusCode') && promptRes['statusCode'] == 7010) ||
                    (promptRes.hasOwnProperty('STATUS_CODE') && promptRes['STATUS_CODE'] == 7010) ||
                    (promptRes.hasOwnProperty('status_code') && promptRes['status_code'] == 7010) ||
                    is_app_api_not_found) {
                    return this.initLibREST("APP").pipe(mergeMap((init_lib_resp) => {
                        if (init_lib_resp.API_RESPONSE.hasOwnProperty('operationList') && init_lib_resp.API_RESPONSE.operationList.length > 0) {
                            return this.gateWayApiCallingREST(operationId, requestBody, conncetionFrom, additonalHeaders, source, accessToken)
                                .pipe(map(rest_resp => {
                                if (rest_resp['STATUS'] != 'E') {
                                    return JSON.stringify(rest_resp.API_RESPONSE);
                                }
                                else {
                                    return JSON.stringify(fail_response);
                                }
                            }));
                        }
                        else {
                            return of(retJson);
                        }
                    }));
                }
            }
            catch (e) {
                return of(retJson);
            }
            return of(retJson);
        }
    }
    gateWayApiCallingREST(operationId, requestBody, conncetionFrom, additonalHeaders, source, accessToken) {
        this.globalSource = source;
        this.sessionrefnumber = this.generateRandom().toString() ? this.generateRandom().toString() : "gyjdyustdysud";
        var randomNumberFordeviceId = this.generateRandom();
        this.device_id = randomNumberFordeviceId + 'APP';
        if (this.environment.checkInternetStatus(source)) {
            this.access_token = accessToken; //localStorage.getItem("access_token");
            if (this.access_token != null && this.access_token != "") {
                try {
                    let URL = this.environment.API_URL + operationId;
                    var reqParams;
                    this.operationData = this.ConvertOptList();
                    var encryptKey;
                    var apiVersion = "v1";
                    if (this.operationData != null) {
                        this.operationData.find((item) => {
                            if (item.publicurl == operationId) {
                                encryptKey = item.hashcode;
                                apiVersion = item.apiversion == undefined ? "v1" : item.apiversion;
                            }
                        });
                    }
                    else {
                        return this.initLibREST("APP").pipe(mergeMap((init_lib_resp) => {
                            if (init_lib_resp.API_RESPONSE.hasOwnProperty('operationList') && init_lib_resp.API_RESPONSE.operationList.length > 0) {
                                return this.gateWayApiCallingREST(operationId, requestBody, conncetionFrom, additonalHeaders, source, accessToken)
                                    .pipe(map(rest_resp => {
                                    if (rest_resp['STATUS'] != 'E') {
                                        return rest_resp;
                                    }
                                    else {
                                        var fail_response = {
                                            "STATUS": "E",
                                            "STATUS_CODE": "7010",
                                            "statusCode": "7010",
                                            "API_RESPONSE": "",
                                            "MESSAGE": "Didn't get response form app"
                                        };
                                        return fail_response;
                                    }
                                }));
                            }
                            else {
                                var fail_response = {
                                    "STATUS": "E",
                                    "STATUS_CODE": "7010",
                                    "statusCode": "7010",
                                    "API_RESPONSE": "",
                                    "MESSAGE": "Didn't get response form app"
                                };
                                return of(fail_response);
                            }
                        }));
                    }
                    if (encryptKey != '' && encryptKey != null) {
                        reqParams = this.encryptionFun(requestBody, encryptKey, "");
                    }
                    else {
                        reqParams = requestBody;
                    }
                    var response;
                    var apiResponse;
                    var api_Response;
                    var headers = {};
                    //headers function call in app env service
                    headers = this.environment.conncetionFromApiHeadersREST(this.access_token, this.device_id, conncetionFrom, this.sessionrefnumber, apiVersion);
                    if (additonalHeaders != null && additonalHeaders != "") {
                        for (const key in additonalHeaders) {
                            headers[key] = additonalHeaders[key];
                        }
                    }
                    return Observable.create((observer) => {
                        let localData = this.httpClient.post(URL, reqParams, { headers }).pipe(catchError(this.environment.handleError));
                        localData.subscribe(res => {
                            this.result = res;
                            response = this.result;
                            if (encryptKey != "") {
                                if (res.STATUS == 'E') {
                                    apiResponse = this.result;
                                }
                                else {
                                    response = response.toString();
                                    response = response.replace(/"/g, ''); //.replaceAll('"', '');
                                    apiResponse = JSON.parse(this.decryptionFun(response, encryptKey, ""));
                                }
                            }
                            else {
                                apiResponse = this.result;
                            }
                            let fail_response = {
                                "STATUS": "E",
                                "API_RESPONSE": "",
                                "MESSAGE": "Sorry unable to connect please try again",
                                "STATUS_CODE": "408"
                            };
                            api_Response = apiResponse ? apiResponse : fail_response;
                            this.return_JSON = {
                                "STATUS": "S",
                                "MESSAGE": "SUCCESS",
                                "STATUS_CODE": "SUCCESS",
                                "API_RESPONSE": api_Response
                            };
                            observer.next(this.return_JSON);
                            // observer.complete();
                        }, (err) => {
                            // IF Status code 500 or 4014 call refresh api after that call gateway api  
                            this.return_JSON = {
                                "STATUS": "S",
                                "MESSAGE": "Failure",
                                "STATUS_CODE": err.STATUS_CODE,
                                "API_RESPONSE": api_Response
                            };
                        });
                    });
                }
                catch (ex) {
                    this.return_JSON = {
                        "STATUS": "E",
                        "API_RESPONSE": "",
                        "MESSAGE": "EXCEPTION : " + ex.message,
                        "STATUS_CODE": "505"
                    };
                }
            }
            else {
                this.return_JSON = {
                    "STATUS": "E",
                    "STATUS_CODE": "500",
                    "statusCode": "7010",
                    "API_RESPONSE": "",
                    "MESSAGE": "Access Token blank"
                };
            }
        }
        else {
            this.return_JSON = {
                "STATUS": "E",
                "STATUS_CODE": "ERROR",
                "statusCode": "",
                "API_RESPONSE": "",
                "MESSAGE": "Please check your Internet Connection."
            };
        }
        return of(this.return_JSON);
    }
    //for internal api calling
    userApiCall(operationId, requestBody, accessToken, source) {
        this.globalSource = source;
        if (this.globalSource == "WEB") {
            if (this.environment.checkInternetStatus(source)) {
                if (this.access_token != null && this.access_token != "") {
                    try {
                        let URL = this.environment.API_URL + operationId;
                        var reqParams;
                        this.operationData = this.ConvertOptList();
                        var encryptKey;
                        var apiVersion = "v1";
                        if (this.operationData != null) {
                            this.operationData.find((item) => {
                                if (item.publicurl == operationId) {
                                    encryptKey = item.hashcode;
                                    apiVersion = item.apiversion == undefined ? "v1" : item.apiversion;
                                }
                            });
                        }
                        // if (operationId == 'oauth-token' || operationId == 'oauth-token-web') {
                        //   encryptKey = 'G3K4M6P7Q8S2J3M5'    //'G7R7ROSVL1E9DIZG';
                        // } else 
                        if (operationId == 'refreshtoken') {
                            encryptKey = "2J4M5N6Q8R9S3K4M";
                        }
                        if (encryptKey != '' && encryptKey != null) {
                            reqParams = this.encryptionFun(requestBody, encryptKey, "");
                        }
                        else {
                            reqParams = requestBody;
                        }
                        var response;
                        var apiResponse;
                        var api_Response;
                        var headers = {};
                        if (operationId == 'refreshtoken') {
                            headers = this.environment.refreshTokenApiHeaders(this.access_token, this.device_id, this.sessionrefnumber);
                        }
                        else if (operationId == "oauth-otp-validate") {
                            headers = this.environment.OuthOtpValidateApiHeaders(this.sessionrefnumber, apiVersion);
                        }
                        else if (operationId == "oauth-token" || operationId == 'oauth-token-web') {
                            headers = this.environment.OuthtokenApiHeaders(accessToken, this.device_id, this.sessionrefnumber, apiVersion);
                        }
                        else {
                            headers = this.environment.CommonApiHeaders(this.access_token, this.device_id, this.sessionrefnumber, apiVersion);
                        }
                        //console.log("headers", headers, URL);
                        return Observable.create((observer) => {
                            let localData = this.httpClient.post(URL, reqParams, { headers }).pipe(catchError(this.environment.handleError));
                            localData.subscribe(res => {
                                this.result = res;
                                response = this.result;
                                if (encryptKey != "") {
                                    if (res.STATUS == 'E') {
                                        apiResponse = this.result;
                                    }
                                    else {
                                        response = response.toString();
                                        response = response.replaceAll('"', '');
                                        apiResponse = JSON.parse(this.decryptionFun(response, encryptKey, ""));
                                    }
                                }
                                else {
                                    apiResponse = this.result;
                                }
                                let fail_response = {
                                    "STATUS": "E",
                                    "API_RESPONSE": "",
                                    "MESSAGE": "Sorry unable to connect please try again",
                                    "STATUS_CODE": "ERROR"
                                };
                                api_Response = apiResponse ? apiResponse : fail_response;
                                this.return_JSON = {
                                    "STATUS": "S",
                                    "MESSAGE": "SUCCESS",
                                    "STATUS_CODE": "SUCCESS",
                                    "API_RESPONSE": api_Response
                                };
                                observer.next(this.return_JSON);
                                observer.complete();
                            }, (err) => {
                                observer.next(err);
                                observer.complete();
                            });
                        });
                    }
                    catch (ex) {
                        this.return_JSON = {
                            "STATUS": "E",
                            "API_RESPONSE": "",
                            "MESSAGE": "EXCEPTION : " + ex.message,
                            "STATUS_CODE": "EXCEPTION",
                        };
                    }
                }
                else {
                    this.return_JSON = {
                        "STATUS": "E",
                        "STATUS_CODE": "ERROR",
                        "API_RESPONSE": "",
                        "MESSAGE": "Access Token blank"
                    };
                }
            }
            else {
                this.return_JSON = {
                    "STATUS": "E",
                    "STATUS_CODE": "ERROR",
                    "API_RESPONSE": "",
                    "MESSAGE": "Please check your Internet Connection."
                };
            }
        }
        else {
            let apiRequestData = {
                "encryptionKey": "",
                "payload": requestBody,
                "operation": operationId
            };
            let headerData = {
                "sessionref": this.device_id
            };
            apiRequestData.headers = headerData;
            this.promptres = prompt("callAPI://" + JSON.stringify(apiRequestData));
            this.return_JSON = this.promptres ? this.promptres : "Sorry unable to connect please try again.";
            return of(this.return_JSON);
        }
        return this.return_JSON;
    }
    // for Api Calling : other Prompts Calls
    otherPromptsCalls(promptKey, promptRequestData, source) {
        var promptresFail = {
            "STATUS": "E",
            "API_RESPONSE": "",
            "MESSAGE": "Unable to connect to APP",
            "STATUS_CODE": "505"
        };
        if (source == "WEB" || source == "Web" || source == "web") {
            this.promptres = {
                "STATUS": "E",
                "API_RESPONSE": "",
                "MESSAGE": "Not for Web froms",
                "STATUS_CODE": "505"
            };
            return this.bannerRes = this.promptres;
        }
        else {
            switch (promptKey) {
                case 'checkStoragePermission://':
                    this.promptres = prompt("checkStoragePermission://" + JSON.stringify(promptRequestData));
                    break;
                case 'device_ip_address':
                    this.promptres = prompt("device_ip_address" + JSON.stringify(promptRequestData));
                    this.promptres = this.promptres ? '' : '127.0.0.1';
                    break;
                default:
                    if (promptRequestData != "" || promptRequestData != null) {
                        this.promptres = prompt(promptKey + JSON.stringify(promptRequestData));
                    }
                    else {
                        this.promptres = prompt(promptKey);
                    }
                    break;
            }
            this.bannerRes = this.promptres ? this.promptres : promptresFail;
        }
        ////console.log('this.bannerRes', this.bannerRes);
        this.bannerRes = this.bannerRes;
        return of(this.bannerRes);
    }
    //for encrypted opt list decryption list
    ConvertOptList() {
        this.optData = localStorage.getItem("operationListData");
        let decryptLocalstorage;
        if (this.optData !== null) {
            // for decrypt code  
            var bytes = JSON.parse(this.decryptionFun(this.optData, this.storageKeyCipher, ""));
            let encryptKey;
            decryptLocalstorage = bytes['operationList'];
        }
        else {
            decryptLocalstorage = null;
        }
        return decryptLocalstorage;
    }
    ConvertOptListREST() {
        this.optData = localStorage.getItem("operationListData");
        let decryptLocalstorage;
        if (this.optData !== null) {
            // for decrypt code  
            var bytes = JSON.parse(this.decryptionFun(this.optData, this.storageKeyCipher, ""));
            let encryptKey;
            decryptLocalstorage = bytes['API_RESPONSE']['operationList']; //bytes['API_RESPONSE']['operationList'];
        }
        else {
            decryptLocalstorage = null;
        }
        return decryptLocalstorage;
    }
    //for encryption
    encryptionFun(req, encryptKey, IV) {
        var keyUtf8 = CryptoJS.enc.Utf8.parse(encryptKey);
        let encrypted = CryptoJS.AES.encrypt(JSON.stringify(req), keyUtf8, {
            keySize: 16,
            mode: CryptoJS.mode.ECB,
            padding: CryptoJS.pad.Pkcs7
        });
        let encryptedString = encrypted.toString();
        return encryptedString;
    }
    //for decryption :
    decryptionFun(response, encryptKey, IV) {
        let keyUtf8 = CryptoJS.enc.Utf8.parse(encryptKey);
        var decrypted = CryptoJS.AES.decrypt(response, keyUtf8, {
            keySize: 16,
            mode: CryptoJS.mode.ECB,
            padding: CryptoJS.pad.Pkcs7
        });
        return decrypted.toString(CryptoJS.enc.Utf8).toString();
    }
    //for Api calling : AEM api calling
    AEMapicalling(redirectionType, requestData, source) {
        var promptresFail = {
            "STATUS": "E",
            "API_RESPONSE": "",
            "MESSAGE": "Unable to connect to APP",
            "STATUS_CODE": "505"
        };
        if (this.environment.checkInternetStatus(source)) {
            if (source == "WEB") {
                return Observable.create((observer) => {
                    let localData = this.httpClient.get(requestData.URL).pipe(catchError(this.environment.handleError));
                    localData.subscribe(response => {
                        var res = {
                            "STATUS": "S",
                            "MESSAGE": "SUCCESS",
                            "STATUS_CODE": "SUCCESS",
                            "API_RESPONSE": response
                        };
                        observer.next(res);
                        observer.complete();
                        return observer;
                    }, (err) => {
                        var res = {
                            "STATUS": "E",
                            "MESSAGE": "Exception" + err,
                            "STATUS_CODE": "SUCCESS",
                            "API_RESPONSE": ""
                        };
                        observer.error(res);
                        observer.complete();
                        return observer;
                    });
                });
            }
            else {
                //send backup by sidhi
                this.promptres = prompt(JSON.stringify(redirectionType) + JSON.stringify(requestData));
                this.return_JSON = this.promptres ? this.promptres : promptresFail;
                return of(this.return_JSON);
            }
        }
        else {
            return this.return_JSON = {
                "STATUS": "E",
                "STATUS_CODE": "ERROR",
                "API_RESPONSE": "",
                "MESSAGE": "Please check your Internet Connection."
            };
        }
    }
    //for Api calling : otp Generation 
    otpGeneration(operationId, requestBody, additonalHeaders, source) {
        this.globalSource = source;
        if (this.globalSource == "WEB") {
            if (this.environment.checkInternetStatus(source)) {
                try {
                    let URL = this.environment.API_URL + operationId;
                    var reqParams;
                    var encryptKey;
                    var apiVersion = "v1";
                    this.operationData = this.ConvertOptList();
                    if (this.operationData != null) {
                        this.operationData.find((item) => {
                            if (item.publicurl == operationId) {
                                encryptKey = item.hashcode;
                                apiVersion = item.apiversion == undefined ? "v1" : item.apiversion;
                            }
                        });
                    }
                    if (encryptKey != '' && encryptKey != null) {
                        reqParams = this.encryptionFun(requestBody, encryptKey, "");
                    }
                    else {
                        reqParams = requestBody;
                    }
                    var response;
                    var apiResponse;
                    var api_Response;
                    var headers = {};
                    if (operationId == 'oauth-otp' || operationId == 'oauth-otp-web') {
                        // headers = this.environment.OuthOtpApiHeaders();
                        headers = this.environment.OuthOtpApiHeaders(this.device_id, this.sessionrefnumber, apiVersion);
                    }
                    if (additonalHeaders != null || additonalHeaders != "") {
                        // headers.additonalHeaders = additonalHeaders;
                    }
                    //console.log('headers', headers);
                    return Observable.create((observer) => {
                        let localData = this.httpClient.post(URL, reqParams, { headers }).pipe(catchError(this.environment.handleError));
                        localData.subscribe(res => {
                            this.result = res;
                            response = this.result;
                            if (encryptKey != "" && operationId == 'oauth-otp-web') {
                                response = response.toString();
                                response = response.replaceAll('"', '');
                                apiResponse = JSON.parse(this.decryptionFun(response, encryptKey, ""));
                            }
                            else {
                                apiResponse = this.result;
                            }
                            let fail_response = {
                                "STATUS": "E",
                                "API_RESPONSE": "",
                                "MESSAGE": "Sorry unable to connect please try again",
                                "STATUS_CODE": "505"
                            };
                            api_Response = apiResponse ? apiResponse : fail_response;
                            this.return_JSON = {
                                "STATUS": "S",
                                "MESSAGE": "SUCCESS",
                                "STATUS_CODE": "SUCCESS",
                                "API_RESPONSE": api_Response
                            };
                            observer.next(this.return_JSON);
                            observer.complete();
                        }, (err) => {
                            observer.next(err);
                            observer.complete();
                        });
                    });
                }
                catch (ex) {
                    this.return_JSON = {
                        "STATUS": "E",
                        "API_RESPONSE": "",
                        "MESSAGE": "EXCEPTION : " + ex.message,
                        "STATUS_CODE": "505"
                    };
                }
            }
            else {
                this.return_JSON = {
                    "STATUS": "E",
                    "STATUS_CODE": "505",
                    "API_RESPONSE": "",
                    "MESSAGE": "Please check your Internet Connection.",
                };
            }
        }
        else {
            let apiRequestData = {
                "encryptionKey": "",
                "payload": requestBody,
                "operation": operationId
            };
            if (additonalHeaders != null || additonalHeaders != "") {
                apiRequestData.additonalHeaders = additonalHeaders;
            }
            this.promptres = prompt("callAPI://" + JSON.stringify(apiRequestData));
            this.return_JSON = this.promptres ? this.promptres : "Sorry unable to connect please try again.";
            return of(this.return_JSON);
        }
        return this.return_JSON;
    }
    otpGenerationREST(operationId, requestBody, additonalHeaders, source) {
        this.globalSource = source;
        // if (this.globalSource == "WEB") {
        if (this.environment.checkInternetStatus(source)) {
            try {
                let URL = this.environment.API_URL + operationId;
                var reqParams;
                var encryptKey;
                var apiVersion = "v1";
                this.operationData = this.ConvertOptList();
                if (this.operationData != null) {
                    this.operationData.find((item) => {
                        if (item.publicurl == operationId) {
                            encryptKey = item.hashcode;
                            apiVersion = item.apiversion == undefined ? "v1" : item.apiversion;
                        }
                    });
                }
                if (encryptKey != '' && encryptKey != null) {
                    reqParams = this.encryptionFun(requestBody, encryptKey, "");
                }
                else {
                    reqParams = requestBody;
                }
                var response;
                var apiResponse;
                var api_Response;
                var headers = {};
                if (operationId == 'oauth-otp' || operationId == 'oauth-otp-web') {
                    // headers = this.environment.OuthOtpApiHeaders();
                    headers = this.environment.OuthOtpApiHeaders(this.device_id, this.sessionrefnumber, apiVersion);
                }
                if (additonalHeaders != null || additonalHeaders != "") {
                    // headers.additonalHeaders = additonalHeaders;
                }
                //console.log('headers', headers);
                return Observable.create((observer) => {
                    let localData = this.httpClient.post(URL, reqParams, { headers }).pipe(catchError(this.environment.handleError));
                    localData.subscribe(res => {
                        this.result = res;
                        response = this.result;
                        if (encryptKey != "" && operationId == 'oauth-otp-web') {
                            response = response.toString();
                            response = response.replaceAll('"', '');
                            apiResponse = JSON.parse(this.decryptionFun(response, encryptKey, ""));
                        }
                        else {
                            apiResponse = this.result;
                        }
                        let fail_response = {
                            "STATUS": "E",
                            "API_RESPONSE": "",
                            "MESSAGE": "Sorry unable to connect please try again",
                            "STATUS_CODE": "505"
                        };
                        api_Response = apiResponse ? apiResponse : fail_response;
                        this.return_JSON = {
                            "STATUS": "S",
                            "MESSAGE": "SUCCESS",
                            "STATUS_CODE": "SUCCESS",
                            "API_RESPONSE": api_Response
                        };
                        observer.next(this.return_JSON);
                        observer.complete();
                    }, (err) => {
                        observer.next(err);
                        observer.complete();
                    });
                });
            }
            catch (ex) {
                this.return_JSON = {
                    "STATUS": "E",
                    "API_RESPONSE": "",
                    "MESSAGE": "EXCEPTION : " + ex.message,
                    "STATUS_CODE": "505"
                };
            }
        }
        else {
            this.return_JSON = {
                "STATUS": "E",
                "STATUS_CODE": "505",
                "API_RESPONSE": "",
                "MESSAGE": "Please check your Internet Connection.",
            };
        }
        // } 
        // else {
        //   let apiRequestData: any = {
        //     "encryptionKey": "",
        //     "payload": requestBody,
        //     "operation": operationId
        //   }
        //   if (additonalHeaders != null || additonalHeaders != "") {
        //     apiRequestData.additonalHeaders = additonalHeaders;
        //   }
        //   this.promptres = prompt("callAPI://" + JSON.stringify(apiRequestData));
        //   this.return_JSON = this.promptres ? this.promptres : "Sorry unable to connect please try again.";
        //   return of(this.return_JSON);
        // }
        return this.return_JSON;
    }
    //for Api calling : otp  Validation
    otpValidation(operationId, requestBody, accessToken, additonalHeaders, source) {
        this.globalSource = source;
        if (this.globalSource == "WEB") {
            if (this.environment.checkInternetStatus(source)) {
                this.access_token = accessToken;
                if (this.access_token != null || this.access_token != "") {
                    try {
                        let URL = this.environment.API_URL + operationId;
                        //console.log("OTP Validation URL is done",URL)
                        var reqParams;
                        var encryptKey;
                        var apiVersion = "v1";
                        //Taking the encryption key from the operational List.
                        this.operationData = this.ConvertOptList();
                        if (this.operationData != null) {
                            this.operationData.find((item) => {
                                if (item.publicurl == operationId) {
                                    encryptKey = item.hashcode;
                                    apiVersion = item.apiversion == undefined ? "v1" : item.apiversion;
                                }
                            });
                        }
                        // if (operationId == 'oauth-token' || operationId == 'oauth-token-web') {
                        //   encryptKey = 'G3K4M6P7Q8S2J3M5'         //'G7R7ROSVL1E9DIZG';
                        // }
                        //console.log("encryptKeyencryptKeycheckVind", encryptKey);
                        if (encryptKey != '' && encryptKey != null) {
                            reqParams = this.encryptionFun(requestBody, encryptKey, "");
                        }
                        else {
                            reqParams = requestBody;
                        }
                        var response;
                        var apiResponse;
                        var api_Response;
                        var headers = {};
                        if (operationId == "oauth-token" || operationId == "oauth-token-web") {
                            // headers = this.environment.OuthtokenApiHeaders(accessToken);
                            headers = this.environment.OuthtokenApiHeaders(accessToken, this.device_id, this.sessionrefnumber, apiVersion);
                        }
                        else {
                            headers = this.environment.CommonApiHeaders(this.access_token, this.device_id, this.sessionrefnumber, apiVersion);
                        }
                        if (additonalHeaders != null || additonalHeaders != "") {
                            // headers.additonalHeaders = additonalHeaders;
                        }
                        //console.log('headers', headers);
                        return Observable.create((observer) => {
                            let localData = this.httpClient.post(URL, reqParams, { headers }).pipe(catchError(this.environment.handleError));
                            localData.subscribe(res => {
                                this.result = res;
                                response = this.result;
                                if (encryptKey != "") {
                                    if (operationId == 'oauth-token') {
                                        if (!this.result.error || res.STATUS == 'E') {
                                            // localStorage.setItem('access_token', this.result.access_token);
                                            // localStorage.setItem('refresh_token', this.result.refresh_token);
                                        }
                                        this.access_token = this.result.access_token;
                                        apiResponse = this.result;
                                    }
                                    else {
                                        response = response.toString();
                                        response = response.replaceAll('"', '');
                                        apiResponse = JSON.parse(this.decryptionFun(response, encryptKey, ""));
                                    }
                                }
                                else {
                                    apiResponse = this.result;
                                }
                                let fail_response = {
                                    "STATUS": "E",
                                    "API_RESPONSE": "",
                                    "MESSAGE": "Sorry unable to connect please try again",
                                    "STATUS_CODE": "ERROR"
                                };
                                api_Response = apiResponse ? apiResponse : fail_response;
                                this.return_JSON = {
                                    "STATUS": "S",
                                    "MESSAGE": "SUCCESS",
                                    "STATUS_CODE": "SUCCESS",
                                    "API_RESPONSE": api_Response
                                };
                                observer.next(this.return_JSON);
                                observer.complete();
                            }, (err) => {
                                this.return_JSON = {
                                    "STATUS": "S",
                                    "MESSAGE": "Failure",
                                    "STATUS_CODE": err.STATUS_CODE,
                                    "API_RESPONSE": api_Response
                                };
                            });
                        });
                    }
                    catch (ex) {
                        this.return_JSON = {
                            "STATUS": "E",
                            "API_RESPONSE": "",
                            "MESSAGE": "EXCEPTION : " + ex.message,
                            "STATUS_CODE": "EXCEPTION",
                        };
                    }
                }
                else {
                    this.return_JSON = {
                        "STATUS": "E",
                        "STATUS_CODE": "ERROR",
                        "API_RESPONSE": "",
                        "MESSAGE": "Access Token blank"
                    };
                }
            }
            else {
                this.return_JSON = {
                    "STATUS": "E",
                    "STATUS_CODE": "ERROR",
                    "API_RESPONSE": "",
                    "MESSAGE": "Please check your Internet Connection."
                };
            }
        }
        else {
            let apiRequestData = {
                "encryptionKey": "",
                "payload": requestBody,
                "operation": operationId
            };
            let headerData = {
                "sessionref": this.device_id
            };
            apiRequestData.headers = headerData;
            this.promptres = prompt("callAPI://" + JSON.stringify(apiRequestData));
            this.return_JSON = this.promptres ? this.promptres : "Sorry unable to connect please try again.";
            return of(this.return_JSON);
        }
        return this.return_JSON;
    }
    otpValidationREST(operationId, requestBody, accessToken, additonalHeaders, source) {
        this.globalSource = source;
        // if (this.globalSource == "WEB") {
        if (this.environment.checkInternetStatus(source)) {
            this.access_token = accessToken;
            if (this.access_token != null || this.access_token != "") {
                try {
                    let URL = this.environment.API_URL + operationId;
                    //console.log("OTP Validation URL is done",URL)
                    var reqParams;
                    var encryptKey;
                    var apiVersion = "v1";
                    //Taking the encryption key from the operational List.
                    this.operationData = this.ConvertOptList();
                    if (this.operationData != null) {
                        this.operationData.find((item) => {
                            if (item.publicurl == operationId) {
                                encryptKey = item.hashcode;
                                apiVersion = item.apiversion == undefined ? "v1" : item.apiversion;
                            }
                        });
                    }
                    // if (operationId == 'oauth-token' || operationId == 'oauth-token-web') {
                    //   encryptKey = 'G3K4M6P7Q8S2J3M5'         //'G7R7ROSVL1E9DIZG';
                    // }
                    //console.log("encryptKeyencryptKeycheckVind", encryptKey);
                    if (encryptKey != '' && encryptKey != null) {
                        reqParams = this.encryptionFun(requestBody, encryptKey, "");
                    }
                    else {
                        reqParams = requestBody;
                    }
                    var response;
                    var apiResponse;
                    var api_Response;
                    var headers = {};
                    if (operationId == "oauth-token" || operationId == "oauth-token-web") {
                        // headers = this.environment.OuthtokenApiHeaders(accessToken);
                        headers = this.environment.OuthtokenApiHeaders(accessToken, this.device_id, this.sessionrefnumber, apiVersion);
                    }
                    else {
                        headers = this.environment.CommonApiHeaders(this.access_token, this.device_id, this.sessionrefnumber, apiVersion);
                    }
                    if (additonalHeaders != null || additonalHeaders != "") {
                        // headers.additonalHeaders = additonalHeaders;
                    }
                    //console.log('headers', headers);
                    return Observable.create((observer) => {
                        let localData = this.httpClient.post(URL, reqParams, { headers }).pipe(catchError(this.environment.handleError));
                        localData.subscribe(res => {
                            this.result = res;
                            response = this.result;
                            if (encryptKey != "") {
                                if (operationId == 'oauth-token') {
                                    if (!this.result.error || res.STATUS == 'E') {
                                        // localStorage.setItem('access_token', this.result.access_token);
                                        // localStorage.setItem('refresh_token', this.result.refresh_token);
                                    }
                                    this.access_token = this.result.access_token;
                                    apiResponse = this.result;
                                }
                                else {
                                    response = response.toString();
                                    response = response.replaceAll('"', '');
                                    apiResponse = JSON.parse(this.decryptionFun(response, encryptKey, ""));
                                }
                            }
                            else {
                                apiResponse = this.result;
                            }
                            let fail_response = {
                                "STATUS": "E",
                                "API_RESPONSE": "",
                                "MESSAGE": "Sorry unable to connect please try again",
                                "STATUS_CODE": "ERROR"
                            };
                            api_Response = apiResponse ? apiResponse : fail_response;
                            this.return_JSON = {
                                "STATUS": "S",
                                "MESSAGE": "SUCCESS",
                                "STATUS_CODE": "SUCCESS",
                                "API_RESPONSE": api_Response
                            };
                            observer.next(this.return_JSON);
                            observer.complete();
                        }, (err) => {
                            this.return_JSON = {
                                "STATUS": "S",
                                "MESSAGE": "Failure",
                                "STATUS_CODE": err.STATUS_CODE,
                                "API_RESPONSE": api_Response
                            };
                        });
                    });
                }
                catch (ex) {
                    this.return_JSON = {
                        "STATUS": "E",
                        "API_RESPONSE": "",
                        "MESSAGE": "EXCEPTION : " + ex.message,
                        "STATUS_CODE": "EXCEPTION",
                    };
                }
            }
            else {
                this.return_JSON = {
                    "STATUS": "E",
                    "STATUS_CODE": "ERROR",
                    "API_RESPONSE": "",
                    "MESSAGE": "Access Token blank"
                };
            }
        }
        else {
            this.return_JSON = {
                "STATUS": "E",
                "STATUS_CODE": "ERROR",
                "API_RESPONSE": "",
                "MESSAGE": "Please check your Internet Connection."
            };
        }
        // } 
        // else {
        //   let apiRequestData: any = {
        //     "encryptionKey": "",
        //     "payload": requestBody,
        //     "operation": operationId
        //   }
        //   let headerData = {
        //     "sessionref": this.device_id
        //   }
        //   apiRequestData.headers = headerData;
        //   this.promptres = prompt("callAPI://" + JSON.stringify(apiRequestData));
        //   this.return_JSON = this.promptres ? this.promptres : "Sorry unable to connect please try again.";
        //   return of(this.return_JSON);
        // }
        return this.return_JSON;
    }
    //for clear data 
    clearData() {
        localStorage.clear();
    }
    setAuthValues(accessToken, mobileNumber) {
        localStorage.setItem('access_token', accessToken);
        localStorage.setItem('mobileNumber', mobileNumber);
    }
    makeSessionRefEmpty() {
        this.sessionrefnumber = "";
    }
    static { this.ɵfac = function ConnectionMgrService_Factory(t) { return new (t || ConnectionMgrService)(i0.ɵɵinject(i1$1.HttpClient), i0.ɵɵinject(CommonAppEnvService)); }; }
    static { this.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ConnectionMgrService, factory: ConnectionMgrService.ɵfac, providedIn: 'root' }); }
}
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ConnectionMgrService, [{
        type: Injectable,
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: i1$1.HttpClient }, { type: CommonAppEnvService }]; }, null); })();

class ConnectionMgrV2Service {
    constructor(httpclient, environment, connectionmgr) {
        this.httpclient = httpclient;
        this.environment = environment;
        this.connectionmgr = connectionmgr;
        this.sessionref = "sgdsg";
    }
    syncGateWayApiCalling(operationId, requestBody, conncetionFrom, additonalHeaders, source) {
        //console.log("Prod Build 10-10-2022")
        this.device_id = this.environment.getDeviceInfo();
        if ((this.device_id == "" && this.device_id == undefined)) {
            this.device_id = operationId + source;
        }
        //console.log('this.device_id', this.device_id);
        this.globalSource = source;
        if (this.globalSource == "WEB" || this.globalSource == "web" || this.globalSource == "Web") {
            if (this.environment.checkInternetStatus(source)) {
                this.access_token = localStorage.getItem("access_token");
                //console.log("AccessToken", this.access_token)
                if (this.access_token != null && this.access_token != "") {
                    try {
                        //console.log("try");
                        let URL = this.environment.API_URL + operationId;
                        var reqParams;
                        this.operationData = this.ConvertOptList();
                        var encryptKey;
                        var apiVersion = "v1";
                        if (this.operationData != null) {
                            this.operationData.find((item) => {
                                if (item.publicurl == operationId) {
                                    encryptKey = item.hashcode;
                                    apiVersion = item.apiversion == undefined ? "v1" : item.apiversion;
                                    //console.log("EncKey", encryptKey);
                                }
                            });
                        }
                        else {
                            this.connectionmgr.initLib(this.globalSource).subscribe((res) => {
                                var api = res;
                                if (res == null) {
                                    let Str = 'operationListData';
                                    var ciphertext = this.connectionmgr.encryptionFun(res, this.connectionmgr.storageKeyCipher, "");
                                    localStorage.setItem('operationListData', ciphertext);
                                    this.operationListData = ciphertext;
                                    this.operationData = this.ConvertOptList();
                                    if (this.operationData != null) {
                                        this.operationData.find((item) => {
                                            if (item.publicurl == operationId) {
                                                encryptKey = item.hashcode;
                                                apiVersion = item.apiversion == undefined ? "v1" : item.apiversion;
                                            }
                                        });
                                    }
                                }
                            });
                        }
                        if (encryptKey != '' && encryptKey != null) {
                            reqParams = this.connectionmgr.encryptionFun(requestBody, encryptKey, "");
                        }
                        else {
                            reqParams = requestBody;
                        }
                        var response;
                        var apiResponse;
                        var api_Response;
                        var headers = {};
                        //headers function call in app env service
                        headers = this.environment.conncetionFromApiHeaders(this.access_token, this.device_id, conncetionFrom, this.sessionref, apiVersion);
                        // if (additonalHeaders != null && additonalHeaders != "") {
                        //   headers.additonalHeaders = additonalHeaders;
                        // }
                        if (additonalHeaders != null && additonalHeaders != "") {
                            for (const key in additonalHeaders) {
                                headers[key] = additonalHeaders[key];
                            }
                        }
                        //  //console.log('headersData', headers, encryptKey);
                        let responseAPI = this.syncRequest(URL, headers, reqParams);
                        this.excErrorHandle = JSON.parse(responseAPI.body.toString());
                        //exception handling here statuscode
                        if (encryptKey != "") {
                            responseAPI = responseAPI.body.toString();
                            responseAPI = responseAPI.replace(/"/g, ''); //responseAPI.replaceAll('"', '');
                            apiResponse = JSON.parse(this.connectionmgr.decryptionFun(responseAPI, encryptKey, "").toString());
                        }
                        else {
                            apiResponse = this.result;
                        }
                        if (apiResponse)
                            //console.log('apiResponse', "apiResponse");
                            fail_response = {
                                "STATUS": "E",
                                "API_RESPONSE": "",
                                "MESSAGE": "Sorry unable to connect please try again",
                                "STATUS_CODE": "408"
                            };
                        api_Response = apiResponse ? apiResponse : fail_response;
                        this.return_JSON = {
                            "STATUS": "S",
                            "MESSAGE": "SUCCESS",
                            "STATUS_CODE": "SUCCESS",
                            "API_RESPONSE": api_Response
                        };
                    }
                    catch (ex) {
                        this.return_JSON = {
                            "STATUS": "E",
                            "API_RESPONSE": "",
                            "MESSAGE": "EXCEPTION : " + ex.message,
                            "STATUS_CODE": "505"
                        };
                    }
                }
                else {
                    this.return_JSON = {
                        "STATUS": "E",
                        "STATUS_CODE": "500",
                        "API_RESPONSE": "",
                        "MESSAGE": "Access Token blank"
                    };
                }
            }
            else {
                this.return_JSON = {
                    "STATUS": "E",
                    "STATUS_CODE": "ERROR",
                    "API_RESPONSE": "",
                    "MESSAGE": "Please check your Internet Connection."
                };
            }
        }
        else {
            let apiRequestData = {
                "encryptionKey": "",
                "payload": requestBody,
                "operation": operationId
            };
            let headerData = {
                "sessionref": this.device_id
            };
            if (additonalHeaders != null && additonalHeaders != "") {
                for (const key in additonalHeaders) {
                    headerData[key] = additonalHeaders[key];
                }
            }
            apiRequestData.headers = headerData;
            var fail_response = {
                "STATUS": "E",
                "STATUS_CODE": "7010",
                "API_RESPONSE": "",
                "MESSAGE": "Didn't get response form app"
            };
            this.promptres = prompt("callAPI://" + JSON.stringify(apiRequestData));
            //console.log('this.promptres', this.promptres);
            this.return_JSON = this.promptres ? this.promptres : fail_response;
            this.return_JSON;
        }
        return this.return_JSON;
    }
    syncGateWayApiCallingREST(operationId, requestBody, conncetionFrom, additonalHeaders, source, accessToken) {
        //console.log("Prod Build 10-10-2022")
        // this.device_id = this.environment.getDeviceInfo();
        // if ((this.device_id == "" && this.device_id == undefined)) {
        //   this.device_id = operationId + source;
        // }
        //console.log('this.device_id', this.device_id);
        this.globalSource = source;
        // if (this.globalSource == "WEB" || this.globalSource == "web" || this.globalSource == "Web") {
        if (this.environment.checkInternetStatus(source)) {
            this.access_token = accessToken; //localStorage.getItem("access_token");
            //console.log("AccessToken", this.access_token)
            if (this.access_token != null && this.access_token != "") {
                try {
                    //console.log("try");
                    let URL = this.environment.API_URL + operationId;
                    var reqParams;
                    this.operationData = this.ConvertOptList();
                    var encryptKey;
                    var apiVersion = "v1";
                    if (this.operationData != null) {
                        this.operationData.find((item) => {
                            if (item.publicurl == operationId) {
                                encryptKey = item.hashcode;
                                apiVersion = item.apiversion == undefined ? "v1" : item.apiversion;
                                //console.log("EncKey", encryptKey);
                            }
                        });
                    }
                    else {
                        this.connectionmgr.initLibREST(this.globalSource).subscribe((res) => {
                            var api = res;
                            if (res == null) {
                                let Str = 'operationListData';
                                var ciphertext = this.connectionmgr.encryptionFun(res, this.connectionmgr.storageKeyCipher, "");
                                localStorage.setItem('operationListData', ciphertext);
                                this.operationListData = ciphertext;
                                this.operationData = this.ConvertOptList();
                                if (this.operationData != null) {
                                    this.operationData.find((item) => {
                                        if (item.publicurl == operationId) {
                                            encryptKey = item.hashcode;
                                            apiVersion = item.apiversion == undefined ? "v1" : item.apiversion;
                                        }
                                    });
                                }
                            }
                        });
                    }
                    if (encryptKey != '' && encryptKey != null) {
                        reqParams = this.connectionmgr.encryptionFun(requestBody, encryptKey, "");
                    }
                    else {
                        reqParams = requestBody;
                    }
                    var response;
                    var apiResponse;
                    var api_Response;
                    var headers = {};
                    //headers function call in app env service
                    headers = this.environment.conncetionFromApiHeaders(this.access_token, this.device_id, conncetionFrom, this.sessionref, apiVersion);
                    // if (additonalHeaders != null && additonalHeaders != "") {
                    //   headers.additonalHeaders = additonalHeaders;
                    // }
                    if (additonalHeaders != null && additonalHeaders != "") {
                        for (const key in additonalHeaders) {
                            headers[key] = additonalHeaders[key];
                        }
                    }
                    //  //console.log('headersData', headers, encryptKey);
                    let responseAPI = this.syncRequest(URL, headers, reqParams);
                    this.excErrorHandle = JSON.parse(responseAPI.body.toString());
                    //exception handling here statuscode
                    if (encryptKey != "") {
                        responseAPI = responseAPI.body.toString();
                        responseAPI = responseAPI.replaceAll('"', '');
                        apiResponse = JSON.parse(this.connectionmgr.decryptionFun(responseAPI, encryptKey, "").toString());
                    }
                    else {
                        apiResponse = this.result;
                    }
                    // if (apiResponse)
                    //console.log('apiResponse', "apiResponse");
                    let fail_response = {
                        "STATUS": "E",
                        "API_RESPONSE": "",
                        "MESSAGE": "Sorry unable to connect please try again",
                        "STATUS_CODE": "408",
                        "statusCode": "7010",
                    };
                    api_Response = apiResponse ? apiResponse : fail_response;
                    this.return_JSON = {
                        "STATUS": "S",
                        "MESSAGE": "SUCCESS",
                        "STATUS_CODE": "SUCCESS",
                        "API_RESPONSE": api_Response
                    };
                }
                catch (ex) {
                    this.return_JSON = {
                        "STATUS": "E",
                        "API_RESPONSE": "",
                        "MESSAGE": "EXCEPTION : " + ex.message,
                        "STATUS_CODE": "505",
                        "statusCode": "7010",
                    };
                }
            }
            else {
                this.return_JSON = {
                    "STATUS": "E",
                    "STATUS_CODE": "500",
                    "statusCode": "7010",
                    "API_RESPONSE": "",
                    "MESSAGE": "Access Token blank"
                };
            }
        }
        else {
            this.return_JSON = {
                "STATUS": "E",
                "STATUS_CODE": "ERROR",
                "statusCode": "7010",
                "API_RESPONSE": "",
                "MESSAGE": "Please check your Internet Connection."
            };
        }
        return this.return_JSON;
    }
    syncGateWayApiCallingV3(operationId, requestBody, conncetionFrom, additonalHeaders, source, accessToken) {
        //console.log("Prod Build 10-10-2022")
        this.device_id = this.environment.getDeviceInfo();
        if ((this.device_id == "" && this.device_id == undefined)) {
            this.device_id = operationId + source;
        }
        //console.log('this.device_id', this.device_id);
        this.globalSource = source;
        if (this.globalSource == "WEB" || this.globalSource == "web" || this.globalSource == "Web") {
            if (this.environment.checkInternetStatus(source)) {
                this.access_token = localStorage.getItem("access_token");
                //console.log("AccessToken", this.access_token)
                if (this.access_token != null && this.access_token != "") {
                    try {
                        //console.log("try");
                        let URL = this.environment.API_URL + operationId;
                        var reqParams;
                        this.operationData = this.ConvertOptList();
                        var encryptKey;
                        var apiVersion = "v1";
                        if (this.operationData != null) {
                            this.operationData.find((item) => {
                                if (item.publicurl == operationId) {
                                    encryptKey = item.hashcode;
                                    apiVersion = item.apiversion == undefined ? "v1" : item.apiversion;
                                    //console.log("EncKey", encryptKey);
                                }
                            });
                        }
                        else {
                            this.connectionmgr.initLib(this.globalSource).subscribe((res) => {
                                var api = res;
                                if (res == null) {
                                    let Str = 'operationListData';
                                    var ciphertext = this.connectionmgr.encryptionFun(res, this.connectionmgr.storageKeyCipher, "");
                                    localStorage.setItem('operationListData', ciphertext);
                                    this.operationListData = ciphertext;
                                    this.operationData = this.ConvertOptList();
                                    if (this.operationData != null) {
                                        this.operationData.find((item) => {
                                            if (item.publicurl == operationId) {
                                                encryptKey = item.hashcode;
                                                apiVersion = item.apiversion == undefined ? "v1" : item.apiversion;
                                            }
                                        });
                                    }
                                }
                            });
                        }
                        if (encryptKey != '' && encryptKey != null) {
                            reqParams = this.connectionmgr.encryptionFun(requestBody, encryptKey, "");
                        }
                        else {
                            reqParams = requestBody;
                        }
                        var response;
                        var apiResponse;
                        var api_Response;
                        var headers = {};
                        //headers function call in app env service
                        headers = this.environment.conncetionFromApiHeaders(this.access_token, this.device_id, conncetionFrom, this.sessionref, apiVersion);
                        // if (additonalHeaders != null && additonalHeaders != "") {
                        //   headers.additonalHeaders = additonalHeaders;
                        // }
                        if (additonalHeaders != null && additonalHeaders != "") {
                            for (const key in additonalHeaders) {
                                headers[key] = additonalHeaders[key];
                            }
                        }
                        //  //console.log('headersData', headers, encryptKey);
                        let responseAPI = this.syncRequest(URL, headers, reqParams);
                        this.excErrorHandle = JSON.parse(responseAPI.body.toString());
                        //exception handling here statuscode
                        if (encryptKey != "") {
                            responseAPI = responseAPI.body.toString();
                            responseAPI = responseAPI.replaceAll('"', '');
                            apiResponse = JSON.parse(this.connectionmgr.decryptionFun(responseAPI, encryptKey, "").toString());
                        }
                        else {
                            apiResponse = this.result;
                        }
                        if (apiResponse)
                            //console.log('apiResponse', "apiResponse");
                            fail_response = {
                                "STATUS": "E",
                                "API_RESPONSE": "",
                                "MESSAGE": "Sorry unable to connect please try again",
                                "STATUS_CODE": "408",
                                "statusCode": "408"
                            };
                        api_Response = apiResponse ? apiResponse : fail_response;
                        this.return_JSON = {
                            "STATUS": "S",
                            "MESSAGE": "SUCCESS",
                            "STATUS_CODE": "SUCCESS",
                            "API_RESPONSE": api_Response
                        };
                    }
                    catch (ex) {
                        this.return_JSON = {
                            "STATUS": "E",
                            "API_RESPONSE": "",
                            "MESSAGE": "EXCEPTION : " + ex.message,
                            "STATUS_CODE": "505",
                            "statusCode": "505",
                        };
                    }
                }
                else {
                    this.return_JSON = {
                        "STATUS": "E",
                        "STATUS_CODE": "500",
                        "statusCode": "500",
                        "API_RESPONSE": "",
                        "MESSAGE": "Access Token blank"
                    };
                }
            }
            else {
                this.return_JSON = {
                    "STATUS": "E",
                    "STATUS_CODE": "ERROR",
                    "API_RESPONSE": "",
                    "MESSAGE": "Please check your Internet Connection."
                };
            }
        }
        else {
            let apiRequestData = {
                "encryptionKey": "",
                "payload": requestBody,
                "operation": operationId
            };
            let headerData = {
                "sessionref": this.device_id
            };
            // if (additonalHeaders != null || additonalHeaders != "") {
            //   apiRequestData.headers = additonalHeaders;
            // }
            if (additonalHeaders != null && additonalHeaders != "") {
                for (const key in additonalHeaders) {
                    headerData[key] = additonalHeaders[key];
                }
            }
            apiRequestData.headers = headerData;
            var fail_response = {
                "STATUS": "E",
                "STATUS_CODE": "7010",
                "statusCode": "7010",
                "API_RESPONSE": "",
                "MESSAGE": "Didn't get response form app"
            };
            var promptRes = prompt("callAPI://" + JSON.stringify(apiRequestData));
            //console.log('this.promptres', this.promptres);
            var retJson = promptRes ? promptRes : fail_response;
            try {
                //debug
                // var is_app_api_not_found = true
                var is_app_api_not_found = promptRes === "Api Name: " + operationId + " not found" ? true : false;
                if (!is_app_api_not_found) {
                    promptRes = JSON.parse(promptRes);
                }
                if ((promptRes.hasOwnProperty('STATUS_CODE') && promptRes['STATUS_CODE'] == '7010') ||
                    (promptRes.hasOwnProperty('statusCode') && promptRes['statusCode'] == '7010') ||
                    (promptRes.hasOwnProperty('status_code') && promptRes['status_code'] == '7010') ||
                    (promptRes.hasOwnProperty('statusCode') && promptRes['statusCode'] == 7010) ||
                    (promptRes.hasOwnProperty('STATUS_CODE') && promptRes['STATUS_CODE'] == 7010) ||
                    (promptRes.hasOwnProperty('status_code') && promptRes['status_code'] == 7010) ||
                    is_app_api_not_found) {
                    // return this.connectionmgr.initLibREST("APP").pipe(
                    //   mergeMap((init_lib_resp) => {
                    let init_lib_resp = this.syncinitLibREST("APP");
                    if (init_lib_resp.API_RESPONSE.hasOwnProperty('operationList') && init_lib_resp.API_RESPONSE.operationList.length > 0) {
                        var rest_resp = this.syncGateWayApiCallingREST(operationId, requestBody, conncetionFrom, additonalHeaders, source, accessToken);
                        if (rest_resp['STATUS'] != 'E') {
                            return JSON.stringify(rest_resp.API_RESPONSE);
                        }
                        else {
                            return JSON.stringify(fail_response);
                        }
                        // return res.API_RESPONSE
                    }
                    else {
                        return retJson;
                    }
                    // } ))
                }
            }
            catch (e) {
                return retJson;
            }
            return retJson;
        }
        return this.return_JSON;
    }
    async syncGateWayApiCallingV4(operationId, requestBody, conncetionFrom, additonalHeaders, source, accessToken) {
        //console.log("Prod Build 10-10-2022")
        this.device_id = this.environment.getDeviceInfo();
        if ((this.device_id == "" && this.device_id == undefined)) {
            this.device_id = operationId + source;
        }
        //console.log('this.device_id', this.device_id);
        this.globalSource = source;
        if (this.globalSource == "WEB" || this.globalSource == "web" || this.globalSource == "Web") {
            if (this.environment.checkInternetStatus(source)) {
                this.access_token = localStorage.getItem("access_token");
                //console.log("AccessToken", this.access_token)
                if (this.access_token != null && this.access_token != "") {
                    try {
                        //console.log("try");
                        let URL = this.environment.API_URL + operationId;
                        var reqParams;
                        this.operationData = this.ConvertOptList();
                        var encryptKey;
                        var apiVersion = "v1";
                        if (this.operationData != null) {
                            this.operationData.find((item) => {
                                if (item.publicurl == operationId) {
                                    encryptKey = item.hashcode;
                                    apiVersion = item.apiversion == undefined ? "v1" : item.apiversion;
                                    //console.log("EncKey", encryptKey);
                                }
                            });
                        }
                        else {
                            this.connectionmgr.initLib(this.globalSource).subscribe((res) => {
                                var api = res;
                                if (res == null) {
                                    let Str = 'operationListData';
                                    var ciphertext = this.connectionmgr.encryptionFun(res, this.connectionmgr.storageKeyCipher, "");
                                    localStorage.setItem('operationListData', ciphertext);
                                    this.operationListData = ciphertext;
                                    this.operationData = this.ConvertOptList();
                                    if (this.operationData != null) {
                                        this.operationData.find((item) => {
                                            if (item.publicurl == operationId) {
                                                encryptKey = item.hashcode;
                                                apiVersion = item.apiversion == undefined ? "v1" : item.apiversion;
                                            }
                                        });
                                    }
                                }
                            });
                        }
                        if (encryptKey != '' && encryptKey != null) {
                            reqParams = this.connectionmgr.encryptionFun(requestBody, encryptKey, "");
                        }
                        else {
                            reqParams = requestBody;
                        }
                        var response;
                        var apiResponse;
                        var api_Response;
                        var headers = {};
                        //headers function call in app env service
                        headers = this.environment.conncetionFromApiHeaders(this.access_token, this.device_id, conncetionFrom, this.sessionref, apiVersion);
                        // if (additonalHeaders != null && additonalHeaders != "") {
                        //   headers.additonalHeaders = additonalHeaders;
                        // }
                        if (additonalHeaders != null && additonalHeaders != "") {
                            for (const key in additonalHeaders) {
                                headers[key] = additonalHeaders[key];
                            }
                        }
                        //  //console.log('headersData', headers, encryptKey);
                        let responseAPI = await this.httpclient.post(URL, reqParams, { headers }).pipe(catchError(this.environment.handleError)).toPromise(); //this.syncRequest(URL, headers, reqParams);
                        // this.excErrorHandle = JSON.parse(responseAPI.body.toString());
                        //exception handling here statuscode
                        if (encryptKey != "") {
                            responseAPI = responseAPI.toString();
                            responseAPI = responseAPI.replaceAll('"', '');
                            apiResponse = JSON.parse(this.connectionmgr.decryptionFun(responseAPI, encryptKey, "").toString());
                        }
                        else {
                            apiResponse = this.result;
                        }
                        if (apiResponse)
                            //console.log('apiResponse', "apiResponse");
                            fail_response = {
                                "STATUS": "E",
                                "API_RESPONSE": "",
                                "MESSAGE": "Sorry unable to connect please try again",
                                "STATUS_CODE": "408",
                                "statusCode": "408"
                            };
                        api_Response = apiResponse ? apiResponse : fail_response;
                        this.return_JSON = {
                            "STATUS": "S",
                            "MESSAGE": "SUCCESS",
                            "STATUS_CODE": "SUCCESS",
                            "API_RESPONSE": api_Response
                        };
                    }
                    catch (ex) {
                        this.return_JSON = {
                            "STATUS": "E",
                            "API_RESPONSE": "",
                            "MESSAGE": "EXCEPTION : " + ex.message,
                            "STATUS_CODE": "505",
                            "statusCode": "505",
                        };
                    }
                }
                else {
                    this.return_JSON = {
                        "STATUS": "E",
                        "STATUS_CODE": "500",
                        "statusCode": "500",
                        "API_RESPONSE": "",
                        "MESSAGE": "Access Token blank"
                    };
                }
            }
            else {
                this.return_JSON = {
                    "STATUS": "E",
                    "STATUS_CODE": "ERROR",
                    "API_RESPONSE": "",
                    "MESSAGE": "Please check your Internet Connection."
                };
            }
        }
        else {
            let apiRequestData = {
                "encryptionKey": "",
                "payload": requestBody,
                "operation": operationId
            };
            let headerData = {
                "sessionref": this.device_id
            };
            if (additonalHeaders != null && additonalHeaders != "") {
                for (const key in additonalHeaders) {
                    headerData[key] = additonalHeaders[key];
                }
            }
            apiRequestData.headers = headerData;
            var fail_response = {
                "STATUS": "E",
                "STATUS_CODE": "7010",
                "statusCode": "7010",
                "API_RESPONSE": "",
                "MESSAGE": "Didn't get response form app"
            };
            var promptRes = prompt("callAPI://" + JSON.stringify(apiRequestData));
            //console.log('this.promptres', this.promptres);
            var retJson = promptRes ? promptRes : fail_response;
            try {
                //debug
                // var is_app_api_not_found = true
                var is_app_api_not_found = promptRes === "Api Name: " + operationId + " not found" ? true : false;
                if (!is_app_api_not_found) {
                    promptRes = JSON.parse(promptRes);
                }
                if ((promptRes.hasOwnProperty('STATUS_CODE') && promptRes['STATUS_CODE'] == '7010') ||
                    (promptRes.hasOwnProperty('statusCode') && promptRes['statusCode'] == '7010') ||
                    (promptRes.hasOwnProperty('status_code') && promptRes['status_code'] == '7010') ||
                    (promptRes.hasOwnProperty('statusCode') && promptRes['statusCode'] == 7010) ||
                    (promptRes.hasOwnProperty('STATUS_CODE') && promptRes['STATUS_CODE'] == 7010) ||
                    (promptRes.hasOwnProperty('status_code') && promptRes['status_code'] == 7010) ||
                    is_app_api_not_found) {
                    // return this.connectionmgr.initLibREST("APP").pipe(
                    //   mergeMap((init_lib_resp) => {
                    let init_lib_resp = this.syncinitLibREST("APP");
                    if (init_lib_resp.API_RESPONSE.hasOwnProperty('operationList') && init_lib_resp.API_RESPONSE.operationList.length > 0) {
                        var rest_resp = this.syncGateWayApiCallingREST(operationId, requestBody, conncetionFrom, additonalHeaders, source, accessToken);
                        if (rest_resp['STATUS'] != 'E') {
                            return JSON.stringify(rest_resp.API_RESPONSE);
                        }
                        else {
                            return JSON.stringify(fail_response);
                        }
                        // return res.API_RESPONSE
                    }
                    else {
                        return retJson;
                    }
                    // } ))
                }
            }
            catch (e) {
                return retJson;
            }
            return retJson;
        }
        return this.return_JSON;
    }
    syncinitLibREST(source) {
        // console.log("initLib")
        console.log("Prod Build 15-06-2023");
        var randomNumberFordeviceId = this.connectionmgr.generateRandom();
        this.device_id = randomNumberFordeviceId + 'APP';
        var sessionrefnumber = this.connectionmgr.toString() ? this.connectionmgr.toString() : "gyjdyustdysud";
        this.globalSource = source;
        var operationId = 'operationallist';
        var method = "POST";
        var OriginalOPTKey = "W1r4srgzHo4z";
        var encryptKey = this.connectionmgr.tokenForOptList.substring(0, 4) + OriginalOPTKey;
        var requestBody = {
            "appversion": "3in1web_web_1.0.0.12",
            "channel": "3in1web",
            "deviceId": this.device_id,
            "token": this.connectionmgr.tokenForOptList
        };
        let publicKeyPEM = "-----BEGIN PUBLIC KEY-----MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDltEGNmQ56wA1UmF9Svp5Iak+V5ys1MaZf8+IUdEvyFyTvak4SLJfG9LbntLDjTuLq9cWrInMIVOLkEg3JNVf3la70bl6sqF9dC/T4Rs2CaUsTpE9aRVJ13odhZWBO1tjxG5peyH0Xw2LTthoR88aGHBTicsDFmAhRJ95tIDqJlQIDAQAB-----END PUBLIC KEY-----";
        let additonalInfoHeaderDecrypted = "dnh6MXQ5Y1NaOFYwUVB1OmxKQ19lNUNjQ214MkZBdEdyOGt2T2RMV1h2OQ==" + '_' + '3in1web' + '_' + this.device_id;
        let additonalInfo = this.connectionmgr.encryptRSA(additonalInfoHeaderDecrypted, publicKeyPEM);
        if (this.environment.checkInternetStatus(source)) {
            try {
                let URL = this.environment.API_URL + operationId;
                var reqParams;
                if (encryptKey != "") {
                    reqParams = this.connectionmgr.encryptionFun(requestBody, encryptKey, "");
                }
                else {
                    reqParams = requestBody;
                }
                var response;
                var apiResponse;
                var api_Response;
                var headers = {};
                headers = this.environment.optHeaders(this.connectionmgr.tokenForOptList, this.device_id, sessionrefnumber, additonalInfo);
                let responseAPI = this.syncRequest(URL, headers, reqParams);
                this.excErrorHandle = JSON.parse(responseAPI.body.toString());
                //exception handling here statuscode
                if (encryptKey != "") {
                    responseAPI = responseAPI.body.toString();
                    responseAPI = responseAPI.replaceAll('"', '');
                    apiResponse = JSON.parse(this.connectionmgr.decryptionFun(responseAPI, encryptKey, "").toString());
                }
                else {
                    apiResponse = this.result;
                }
                let fail_response = {
                    "STATUS": "E",
                    "API_RESPONSE": "",
                    "MESSAGE": "Sorry unable to connect please try again",
                    "STATUS_CODE": "408"
                };
                api_Response = apiResponse ? apiResponse : fail_response;
                this.return_JSON = {
                    "STATUS": "S",
                    "MESSAGE": "SUCCESS",
                    "STATUS_CODE": "SUCCESS",
                    "API_RESPONSE": api_Response
                };
            }
            catch (ex) {
                this.return_JSON = {
                    "STATUS": "E",
                    "API_RESPONSE": api_Response,
                    "MESSAGE": "EXCEPTION : " + ex.message,
                    "STATUS_CODE": "EXCEPTION",
                };
            }
        }
        else {
            this.return_JSON = {
                "STATUS": "E",
                "STATUS_CODE": "ERROR",
                "API_RESPONSE": "",
                "MESSAGE": "Please check your Internet Connection."
            };
        }
        return this.return_JSON;
    }
    syncRequest(url, headers, reqParams) {
        console.log("req", reqParams.toString());
        var request = require('sync-request');
        var res = request('POST', url, {
            headers,
            json: reqParams
        });
        var result;
        return res;
    }
    ConvertOptList() {
        this.optData = localStorage.getItem("operationListData");
        let decryptLocalstorage;
        if (this.optData !== null) {
            // for decrypt code  
            var bytes = JSON.parse(this.connectionmgr.decryptionFun(this.optData, this.connectionmgr.storageKeyCipher, ""));
            let encryptKey;
            decryptLocalstorage = bytes['operationList'];
        }
        else {
            decryptLocalstorage = null;
        }
        return decryptLocalstorage;
    }
    asyncUserApiCall(operationId, requestBody, accessToken, source) {
        this.globalSource = source;
        //console.log("accessToken",accessToken);
        if (this.globalSource == "WEB") {
            if (this.environment.checkInternetStatus(source)) {
                if (accessToken !== null && accessToken !== "") {
                    try {
                        let URL = this.environment.API_URL + operationId;
                        var reqParams;
                        this.operationData = this.ConvertOptList();
                        var encryptKey;
                        var apiVersion = "v1";
                        if (this.operationData != null) {
                            this.operationData.find((item) => {
                                if (item.publicurl == operationId) {
                                    encryptKey = item.hashcode;
                                    apiVersion = item.apiversion == undefined ? "v1" : item.apiversion;
                                }
                            });
                        }
                        // if (operationId == 'oauth-token-web') {
                        //   encryptKey = 'G3K4M6P7Q8S2J3M5';
                        // } 
                        if (encryptKey != '' && encryptKey != null) {
                            reqParams = this.connectionmgr.encryptionFun(requestBody, encryptKey, "");
                        }
                        else {
                            reqParams = requestBody;
                        }
                        var response;
                        var apiResponse;
                        var api_Response;
                        var headers = {};
                        if (operationId == 'refreshtoken') {
                            headers = this.environment.refreshTokenApiHeaders(this.access_token, this.device_id, this.sessionref);
                        }
                        else if (operationId == "oauth-otp-validate") {
                            headers = this.environment.OuthOtpValidateApiHeaders(this.sessionref, apiVersion);
                        }
                        else if (operationId == "oauth-token") {
                            headers = this.environment.OuthtokenApiHeaders(accessToken, this.device_id, this.sessionref, apiVersion);
                        }
                        else {
                            headers = this.environment.CommonApiHeaders(accessToken, this.device_id, this.sessionref, apiVersion);
                        }
                        let responseAPI = this.syncRequest(URL, headers, reqParams);
                        if (encryptKey != "") {
                            responseAPI = responseAPI.body.toString();
                            responseAPI = responseAPI.replaceAll('"', '');
                            apiResponse = JSON.parse(this.connectionmgr.decryptionFun(responseAPI, encryptKey, ""));
                        }
                        else {
                            apiResponse = this.result;
                        }
                        let fail_response = {
                            "STATUS": "E",
                            "API_RESPONSE": "",
                            "MESSAGE": "Sorry unable to connect please try again",
                            "STATUS_CODE": "408"
                        };
                        api_Response = apiResponse ? apiResponse : fail_response;
                        this.return_JSON = {
                            "STATUS": "S",
                            "MESSAGE": "SUCCESS",
                            "STATUS_CODE": "SUCCESS",
                            "API_RESPONSE": api_Response
                        };
                    }
                    catch (ex) {
                        this.return_JSON = {
                            "STATUS": "E",
                            "API_RESPONSE": "",
                            "MESSAGE": "EXCEPTION : " + ex.message,
                            "STATUS_CODE": "EXCEPTION",
                        };
                    }
                }
                else {
                    //console.log("enter else");
                    return this.return_JSON = {
                        "STATUS": "E",
                        "STATUS_CODE": "ERROR",
                        "API_RESPONSE": "",
                        "MESSAGE": "Access Token blank"
                    };
                }
            }
            else {
                this.return_JSON = {
                    "STATUS": "E",
                    "STATUS_CODE": "ERROR",
                    "API_RESPONSE": "",
                    "MESSAGE": "Please check your Internet Connection."
                };
            }
        }
        else {
            let apiRequestData = {
                "encryptionKey": "",
                "payload": requestBody,
                "operation": operationId
            };
            let headerData = {
                "sessionref": this.device_id
            };
            apiRequestData.headers = headerData;
            this.promptres = prompt("callAPI://" + JSON.stringify(apiRequestData));
            this.return_JSON = this.promptres ? this.promptres : "Sorry unable to connect please try again.";
            return this.return_JSON;
        }
        return this.return_JSON;
    }
    static { this.ɵfac = function ConnectionMgrV2Service_Factory(t) { return new (t || ConnectionMgrV2Service)(i0.ɵɵinject(i1$1.HttpClient), i0.ɵɵinject(CommonAppEnvService), i0.ɵɵinject(ConnectionMgrService)); }; }
    static { this.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ConnectionMgrV2Service, factory: ConnectionMgrV2Service.ɵfac, providedIn: 'root' }); }
}
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ConnectionMgrV2Service, [{
        type: Injectable,
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: i1$1.HttpClient }, { type: CommonAppEnvService }, { type: ConnectionMgrService }]; }, null); })();

/*
 * Public API Surface of lib-api
 */

/**
 * Generated bundle index. Do not edit.
 */

export { CommonAppEnvService, ConnectionMgrService, ConnectionMgrV2Service, LibApiComponent, LibApiModule, LibApiService };
//# sourceMappingURL=lib-api.mjs.map
