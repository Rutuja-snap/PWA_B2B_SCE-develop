import { HttpErrorResponse } from '@angular/common/http';
import { AngularDeviceInformationService } from 'angular-device-information';
import * as i0 from "@angular/core";
export declare class CommonAppEnvService {
    private deviceInformationService;
    production: boolean;
    APP_ENVIRONMENT: string;
    aemUrl: string;
    maintanceAPIUrl: string;
    API_URL: string;
    deviceId: any;
    constructor(deviceInformationService: AngularDeviceInformationService);
    checkInternetStatus(source: any): boolean;
    optHeaders(tokenForOptList: any, deviceId: any, sessionrefnumber: any, additonalInfo: any): {
        'Content-Type': string;
        Accept: string;
        Authorization: string;
        token: any;
        'Connection-from': string;
        source: string;
        deviceId: any;
        apiVersion: string;
        operation: string;
        sessionref: any;
        appVersion: string;
        additionalinfo1: any;
    };
    conncetionFromApiHeaders(access_token: any, deviceId: any, conncetionFrom: any, sessionrefnumber: any, apiVersion: any): any;
    conncetionFromApiHeadersREST(access_token: any, deviceId: any, conncetionFrom: any, sessionrefnumber: any, apiVersion: any): any;
    emiPodApiHeaders(access_token: any, deviceId: any): {
        'Content-Type': string;
        Accept: string;
        Authorization: string;
        token: any;
        'Connection-from': string;
        source: string;
        deviceId: any;
        apiVersion: string;
    };
    OuthOtpApiHeaders(deviceId: any, sessionrefnumber: any, apiVersion: any): {
        'Content-Type': string;
        Accept: string;
        Authorization: string;
        'Connection-from': string;
        source: string;
        deviceId: any;
        apiVersion: any;
        sessionref: any;
    };
    OuthOtpValidateApiHeaders(sessionrefnumber: any, apiVersion: any): {
        'Content-Type': string;
        Accept: string;
        Authorization: string;
        token: string;
        'Connection-from': string;
        source: string;
        apiVersion: any;
        sessionref: any;
    };
    OuthtokenApiHeaders(accessToken: any, deviceId: any, sessionrefnumber: any, apiVersion: any): {
        'Content-Type': string;
        Accept: string;
        Authorization: string;
        token: any;
        'Connection-from': string;
        source: string;
        apiVersion: any;
        deviceId: any;
        sessionref: any;
    };
    CommonApiHeaders(access_token: any, deviceId: any, sessionrefnumber: any, apiVersion: any): {
        'Content-Type': string;
        Accept: string;
        Authorization: string;
        token: any;
        'Connection-from': string;
        source: string;
        deviceId: any;
        apiVersion: any;
        sessionref: any;
    };
    refreshTokenApiHeaders(access_token: any, deviceId: any, sessionrefnumber: any): {
        'Content-Type': string;
        Accept: string;
        Authorization: string;
        token: any;
        'Connection-from': string;
        source: string;
        sessionref: any;
    };
    consoleLog(data: any): void;
    handleError(error: HttpErrorResponse): import("rxjs").Observable<any>;
    getDeviceInfo(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<CommonAppEnvService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CommonAppEnvService>;
}
//# sourceMappingURL=common-app-env.service.d.ts.map