import * as i0 from "@angular/core";
export declare class LibApiService {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<LibApiService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LibApiService>;
}
//# sourceMappingURL=lib-api.service.d.ts.map