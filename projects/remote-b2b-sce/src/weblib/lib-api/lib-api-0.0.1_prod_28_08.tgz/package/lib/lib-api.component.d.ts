import { OnInit } from '@angular/core';
import * as i0 from "@angular/core";
export declare class LibApiComponent implements OnInit {
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LibApiComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LibApiComponent, "la-lib-api", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=lib-api.component.d.ts.map