import { HttpClient } from '@angular/common/http';
import { CommonAppEnvService } from './common-app-env.service';
import { ConnectionMgrService } from './connection-mgr.service';
import * as i0 from "@angular/core";
export declare class ConnectionMgrV2Service {
    private httpclient;
    private environment;
    private connectionmgr;
    device_id: any;
    globalSource: any;
    access_token: any;
    operationData: any;
    return_JSON: any;
    operationListData: any;
    result: any;
    promptres: any;
    optData: any;
    excErrorHandle: any;
    sessionref: any;
    constructor(httpclient: HttpClient, environment: CommonAppEnvService, connectionmgr: ConnectionMgrService);
    syncGateWayApiCalling(operationId: any, requestBody: any, conncetionFrom: any, additonalHeaders: any, source: any): any;
    syncGateWayApiCallingREST(operationId: any, requestBody: any, conncetionFrom: any, additonalHeaders: any, source: any, accessToken: any): any;
    syncGateWayApiCallingV3(operationId: any, requestBody: any, conncetionFrom: any, additonalHeaders: any, source: any, accessToken: any): any;
    syncGateWayApiCallingV4(operationId: any, requestBody: any, conncetionFrom: any, additonalHeaders: any, source: any, accessToken: any): Promise<any>;
    syncinitLibREST(source: any): any;
    syncRequest(url: any, headers: any, reqParams: any): any;
    private ConvertOptList;
    private asyncUserApiCall;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConnectionMgrV2Service, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConnectionMgrV2Service>;
}
//# sourceMappingURL=connection-mgr-v2.service.d.ts.map