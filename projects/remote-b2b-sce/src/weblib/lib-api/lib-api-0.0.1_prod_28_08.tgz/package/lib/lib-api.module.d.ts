import * as i0 from "@angular/core";
import * as i1 from "./lib-api.component";
import * as i2 from "@angular/common/http";
export declare class LibApiModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<LibApiModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LibApiModule, [typeof i1.LibApiComponent], [typeof i2.HttpClientModule], [typeof i1.LibApiComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LibApiModule>;
}
//# sourceMappingURL=lib-api.module.d.ts.map